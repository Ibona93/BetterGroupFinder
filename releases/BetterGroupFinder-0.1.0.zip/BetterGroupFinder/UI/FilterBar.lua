local _, ns = ...

--[[
Filter bar under the Group Finder header. Opens with the funnel button next to Refresh;
the window grows by the bar's height so the list keeps its size.
]]

local Bar = {}
ns.FilterBar = Bar

local LABEL_WIDTH = 104
local CHIP_HEIGHT = 20
local CHIP_GAP = 4
local ROW_GAP = 6
local PADDING = 8

local STYLES = {
	need   = { bg = { 0.16, 0.12, 0.04, 0.95 }, border = { 0.79, 0.64, 0.29, 1 }, text = { 1, 0.82, 0 } },
	pref   = { bg = { 0.11, 0.08, 0.05, 0.95 }, border = { 0.45, 0.37, 0.24, 1 }, text = { 0.95, 0.92, 0.85 } },
	ignore = { bg = { 0.06, 0.05, 0.04, 0.85 }, border = { 0.24, 0.19, 0.13, 1 }, text = { 0.55, 0.52, 0.48 } },
}
local NEXT_STATE = { ignore = "pref", pref = "need", need = "ignore" }

local function styleChip(chip, state)
	local s = STYLES[state] or STYLES.ignore
	chip:SetBackdropColor(unpack(s.bg))
	chip:SetBackdropBorderColor(unpack(s.border))
	chip.Text:SetTextColor(unpack(s.text))
end

local function createChip(parent, onClick)
	local chip = CreateFrame("Button", nil, parent, "BackdropTemplate")
	chip:SetHeight(CHIP_HEIGHT)
	chip:SetBackdrop({
		bgFile = "Interface\\Buttons\\WHITE8X8",
		edgeFile = "Interface\\Buttons\\WHITE8X8",
		edgeSize = 1,
	})
	chip.Text = chip:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	chip.Text:SetPoint("CENTER")
	chip:SetScript("OnClick", function(self)
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) end
		onClick(self)
	end)
	chip:SetScript("OnEnter", function(self)
		if self.tooltip then
			GameTooltip:SetOwner(self, "ANCHOR_TOP")
			GameTooltip:SetText(self.tooltip, 1, 1, 1, 1, true)
			GameTooltip:Show()
		end
	end)
	chip:SetScript("OnLeave", function() GameTooltip:Hide() end)
	return chip
end

local function setChipText(chip, text)
	chip.Text:SetText(text)
	chip:SetWidth(math.ceil(chip.Text:GetStringWidth()) + 16)
end

local function label(parent, text)
	local fs = parent:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
	fs:SetJustifyH("LEFT")
	fs:SetWidth(LABEL_WIDTH - 6)
	fs:SetText(text)
	return fs
end

-- Profile currently edited by the ability chips: follows the category dropdown.
function Bar.CurrentProfile()
	local cat
	local dropdown = LFGBrowseFrame and LFGBrowseFrame.CategoryDropdown
	if dropdown and dropdown.GetValue then
		local ok, value = pcall(dropdown.GetValue, dropdown)
		if ok then cat = value end
	end
	if cat == 114 then return "raid" end
	if cat == 2 or cat == nil then return "dungeon" end
	return "other"
end

function Bar.Create(parent)
	local L = ns.L
	local f = CreateFrame("Frame", "BGFFilterBar", parent)
	Bar.frame = f
	f:Hide()

	f.Bg = f:CreateTexture(nil, "BACKGROUND")
	f.Bg:SetAllPoints()
	f.Bg:SetColorTexture(0.02, 0.015, 0.01, 0.82)
	f.Line = f:CreateTexture(nil, "ARTWORK")
	f.Line:SetPoint("BOTTOMLEFT", 0, -6)
	f.Line:SetPoint("BOTTOMRIGHT", 0, -6)
	if not pcall(f.Line.SetAtlas, f.Line, "groupfinder-ScrollLine", true) then
		f.Line:SetColorTexture(0.42, 0.32, 0.19, 1)
		f.Line:SetHeight(1)
	end

	-- Row 1: enable, perspective, profile
	f.Enable = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
	f.Enable:SetSize(22, 22)
	f.Enable:SetScript("OnClick", function(self)
		ns.db.enabled = self:GetChecked() and true or false
		ns.UI.ApplyEnabled()
	end)
	f.EnableText = f:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
	f.EnableText:SetPoint("LEFT", f.Enable, "RIGHT", 2, 0)
	f.EnableText:SetText(L.ENABLED)
	f.Perspective = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	f.Perspective:SetPoint("LEFT", f.EnableText, "RIGHT", 12, 0)
	f.Profile = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	f.Profile:SetJustifyH("RIGHT")

	-- Row 2: roles
	f.RolesLabel = label(f, L.ROLES_SOLO)
	f.RoleChips = {}
	for _, role in ipairs({ "TANK", "HEALER", "DAMAGER" }) do
		local chip = createChip(f, function() Bar.ToggleRole(role) end)
		chip.role = role
		setChipText(chip, ns.RoleName(role))
		f.RoleChips[#f.RoleChips + 1] = chip
	end
	f.RolesHint = f:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	f.RolesHint:SetText(L.ROLES_HINT)

	-- Row 3: abilities
	f.AbilitiesLabel = label(f, L.ABILITIES)
	f.AbilityChips = {}
	for _, ability in ipairs(ns.ABILITIES) do
		local chip = createChip(f, function() Bar.CycleAbility(ability.id) end)
		chip.ability = ability.id
		setChipText(chip, ns.AbilityName(ability.id))
		f.AbilityChips[#f.AbilityChips + 1] = chip
	end

	-- Row 4: view + legend
	f.ViewLabel = label(f, L.VIEW)
	f.ViewNormal = createChip(f, function() Bar.SetCompact(false) end)
	setChipText(f.ViewNormal, L.VIEW_NORMAL)
	f.ViewCompact = createChip(f, function() Bar.SetCompact(true) end)
	setChipText(f.ViewCompact, L.VIEW_COMPACT)
	f.Legend = f:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	f.Legend:SetJustifyH("RIGHT")
	f.Legend:SetText(L.LEGEND)

	return f
end

-- Lays out all rows for the current width; returns the bar height.
function Bar.Layout()
	local f = Bar.frame
	if not f then return 0 end
	local width = f:GetWidth()
	if not width or width < 100 then width = 440 end
	local y = -PADDING + 2

	f.Enable:ClearAllPoints()
	f.Enable:SetPoint("TOPLEFT", PADDING - 4, y + 2)
	f.Profile:ClearAllPoints()
	f.Profile:SetPoint("TOPRIGHT", -PADDING, y - 3)
	y = y - 24

	local function placeLabel(fs)
		fs:ClearAllPoints()
		fs:SetPoint("TOPLEFT", PADDING, y - 4)
	end

	-- roles
	placeLabel(f.RolesLabel)
	local x = LABEL_WIDTH
	for _, chip in ipairs(f.RoleChips) do
		chip:ClearAllPoints()
		chip:SetPoint("TOPLEFT", x, y)
		x = x + chip:GetWidth() + CHIP_GAP
	end
	f.RolesHint:ClearAllPoints()
	f.RolesHint:SetPoint("LEFT", f.RoleChips[#f.RoleChips], "RIGHT", 8, 0)
	y = y - CHIP_HEIGHT - ROW_GAP

	-- abilities, wrapping
	placeLabel(f.AbilitiesLabel)
	x = LABEL_WIDTH
	for _, chip in ipairs(f.AbilityChips) do
		local w = chip:GetWidth()
		if x + w > width - PADDING and x > LABEL_WIDTH then
			x = LABEL_WIDTH
			y = y - CHIP_HEIGHT - CHIP_GAP
		end
		chip:ClearAllPoints()
		chip:SetPoint("TOPLEFT", x, y)
		x = x + w + CHIP_GAP
	end
	y = y - CHIP_HEIGHT - ROW_GAP

	-- view
	placeLabel(f.ViewLabel)
	f.ViewNormal:ClearAllPoints()
	f.ViewNormal:SetPoint("TOPLEFT", LABEL_WIDTH, y)
	f.ViewCompact:ClearAllPoints()
	f.ViewCompact:SetPoint("LEFT", f.ViewNormal, "RIGHT", CHIP_GAP, 0)
	y = y - CHIP_HEIGHT - 4
	f.Legend:ClearAllPoints()
	f.Legend:SetPoint("TOPRIGHT", -PADDING, y)
	f.Legend:SetPoint("TOPLEFT", PADDING, y)
	y = y - 14 - PADDING

	Bar.height = -y
	return Bar.height
end

-- Automatic role state: solo = your roles, in a group = roles your group still needs.
local function autoRoles()
	local mySide = ns.Engine.GetMySide()
	local out = {}
	if #mySide <= 1 then
		local r = ns.Engine.GetMyRoles()
		out.TANK, out.HEALER, out.DAMAGER = r.tank, r.healer, r.dps
	else
		local targets = ns.GetRoleTargets("dungeon", 5)
		local counts = { TANK = 0, HEALER = 0, DAMAGER = 0 }
		for _, m in ipairs(mySide) do
			local role = m.role or "DAMAGER"
			counts[role] = counts[role] + 1
		end
		for role, target in pairs(targets) do out[role] = counts[role] < target end
	end
	return out, #mySide > 1
end

function Bar.ToggleRole(role)
	local chips = ns.db.roleChips
	if next(chips) == nil then
		local auto = autoRoles()
		for r, on in pairs(auto) do chips[r] = on and true or false end
	end
	chips[role] = not chips[role]
	Bar.Update()
	ns.RequestRefresh()
end

function Bar.CycleAbility(id)
	local profile = Bar.CurrentProfile()
	local states = ns.db.abilityStates[profile]
	states[id] = NEXT_STATE[states[id] or "ignore"]
	Bar.Update()
	ns.RequestRefresh()
end

function Bar.SetCompact(compact)
	ns.db.compact = compact
	Bar.Update()
	ns.RequestRefresh()
end

function Bar.Update()
	local f = Bar.frame
	if not f or not f:IsShown() then return end
	local L = ns.L
	f.Enable:SetChecked(ns.db.enabled)

	local mySide = ns.Engine.GetMySide()
	if #mySide > 1 then
		f.Perspective:SetText(L.RATING_FOR .. " " .. L.YOUR_GROUP .. " (" .. #mySide .. ")")
	else
		local me = mySide[1]
		local roles = {}
		local r = me.lfgRoles or {}
		if r.tank then roles[#roles + 1] = ns.RoleName("TANK") end
		if r.healer then roles[#roles + 1] = ns.RoleName("HEALER") end
		if r.dps then roles[#roles + 1] = ns.RoleName("DAMAGER") end
		f.Perspective:SetText(("%s %s · %s %s %s (%s)"):format(L.RATING_FOR, L.YOU, ns.ClassName(me.class or ""),
			LEVEL_ABBR or "Lvl", tostring(me.level or "?"), table.concat(roles, "/")))
	end

	local profile = Bar.CurrentProfile()
	local profileText
	if profile == "dungeon" then
		profileText = L.PROFILE_DUNGEON
	elseif profile == "raid" then
		profileText = _G.RAID or "Raid"
	else
		profileText = _G.GROUP or "Group"
	end
	f.Profile:SetText(L.PROFILE .. " " .. profileText)

	local auto, inGroup = autoRoles()
	f.RolesLabel:SetText(inGroup and L.ROLES_GROUP or L.ROLES_SOLO)
	local manual = next(ns.db.roleChips) ~= nil
	for _, chip in ipairs(f.RoleChips) do
		local on = manual and ns.db.roleChips[chip.role] or (not manual and auto[chip.role])
		styleChip(chip, on and "need" or "ignore")
	end
	f.RolesHint:SetShown(not manual)

	local states = ns.db.abilityStates[profile] or {}
	for _, chip in ipairs(f.AbilityChips) do
		styleChip(chip, states[chip.ability] or "ignore")
	end
	styleChip(f.ViewNormal, ns.db.compact and "ignore" or "need")
	styleChip(f.ViewCompact, ns.db.compact and "need" or "ignore")
end

function Bar.ResetFilters()
	ns.db.roleChips = {}
	ns.db.abilityStates = ns.CopyTable(ns.DEFAULT_ABILITY_STATES)
	Bar.Update()
	ns.RequestRefresh()
end
