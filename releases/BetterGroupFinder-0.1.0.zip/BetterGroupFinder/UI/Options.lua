local _, ns = ...

--[[
Options: AddOns section of the game settings (falls back to a standalone window).
General switches, message templates per language, reset buttons.
]]

local Options = {}
ns.Options = Options

local panel, category
local editBoxes = {}
local currentLang

local function createCheck(parent, text, getter, setter)
	local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
	cb:SetSize(24, 24)
	cb.Label = cb:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	cb.Label:SetPoint("LEFT", cb, "RIGHT", 4, 0)
	cb.Label:SetText(text)
	cb:SetScript("OnShow", function(self) self:SetChecked(getter()) end)
	cb:SetScript("OnClick", function(self) setter(self:GetChecked() and true or false) end)
	return cb
end

local function saveTemplate(lang, key, text)
	text = (text or ""):gsub("^%s+", ""):gsub("%s+$", "")
	local default = (ns.DefaultTemplates[lang] or {})[key]
	ns.db.templates[lang] = ns.db.templates[lang] or {}
	if text == "" or text == default then
		ns.db.templates[lang][key] = nil
	else
		ns.db.templates[lang][key] = text
	end
end

local function loadTemplates()
	for key, box in pairs(editBoxes) do
		box:SetText(ns.GetTemplate(currentLang, key))
		box:SetCursorPosition(0)
	end
	if panel and panel.LangButtons then
		for _, b in ipairs(panel.LangButtons) do
			b:SetEnabled(b.lang ~= currentLang)
		end
	end
end

local function build()
	local L = ns.L
	panel = CreateFrame("Frame", "BGFOptionsPanel")
	panel.name = L.OPT_TITLE

	local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText(L.OPT_TITLE .. "  |cff808080" .. ns.VERSION .. "|r")

	local autoSend = createCheck(panel, L.OPT_AUTOSEND,
		function() return ns.db.autoSend end, function(v) ns.db.autoSend = v end)
	autoSend:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -14)

	local reasons = createCheck(panel, L.OPT_REASONS,
		function() return ns.db.showReasons end, function(v) ns.db.showReasons = v end)
	reasons:SetPoint("TOPLEFT", autoSend, "BOTTOMLEFT", 0, -4)

	local enabled = createCheck(panel, L.ENABLED,
		function() return ns.db.enabled end,
		function(v) ns.db.enabled = v if ns.UI.ApplyEnabled then ns.UI.ApplyEnabled() end end)
	enabled:SetPoint("TOPLEFT", reasons, "BOTTOMLEFT", 0, -4)

	local header = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	header:SetPoint("TOPLEFT", enabled, "BOTTOMLEFT", 0, -18)
	header:SetText(L.OPT_TEMPLATES)

	local langLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	langLabel:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -10)
	langLabel:SetText(L.OPT_LANGUAGE)

	panel.LangButtons = {}
	local prev
	for i, lang in ipairs(ns.TemplateLanguages()) do
		local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		b:SetText(ns.LANGUAGE_NAMES[lang] or lang)
		b:SetSize(math.max(70, b:GetFontString():GetStringWidth() + 20), 22)
		if i == 1 then
			b:SetPoint("LEFT", langLabel, "RIGHT", 8, 0)
		elseif (i - 1) % 5 == 0 then
			b:SetPoint("TOPLEFT", panel.LangButtons[i - 5], "BOTTOMLEFT", 0, -2)
		else
			b:SetPoint("LEFT", prev, "RIGHT", 4, 0)
		end
		b.lang = lang
		b:SetScript("OnClick", function()
			currentLang = lang
			loadTemplates()
		end)
		panel.LangButtons[i] = b
		prev = b
	end

	local previousBox
	for _, key in ipairs(ns.TEMPLATE_KEYS) do
		local label = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
		if previousBox then
			label:SetPoint("TOPLEFT", previousBox, "BOTTOMLEFT", -6, -10)
		else
			local rows = math.max(1, math.ceil(#panel.LangButtons / 5))
			label:SetPoint("TOPLEFT", langLabel, "BOTTOMLEFT", 0, -16 - (rows - 1) * 24)
		end
		label:SetText(L["OPT_T_" .. key])
		local box = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
		box:SetSize(560, 22)
		box:SetAutoFocus(false)
		box:SetMaxLetters(255)
		box:SetPoint("TOPLEFT", label, "BOTTOMLEFT", 6, -2)
		box:SetScript("OnEnterPressed", function(self)
			saveTemplate(currentLang, key, self:GetText())
			self:ClearFocus()
		end)
		box:SetScript("OnEditFocusLost", function(self)
			saveTemplate(currentLang, key, self:GetText())
		end)
		box:SetScript("OnEscapePressed", function(self)
			self:SetText(ns.GetTemplate(currentLang, key))
			self:ClearFocus()
		end)
		editBoxes[key] = box
		previousBox = box
	end
	panel.lastBox = previousBox

	local hint = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	hint:SetPoint("TOPLEFT", panel.lastBox, "BOTTOMLEFT", -6, -8)
	hint:SetWidth(580)
	hint:SetJustifyH("LEFT")
	hint:SetText(L.OPT_PLACEHOLDERS)

	local resetTemplates = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	resetTemplates:SetText(L.OPT_RESET_TEMPLATES)
	resetTemplates:SetSize(resetTemplates:GetFontString():GetStringWidth() + 30, 24)
	resetTemplates:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, -12)
	resetTemplates:SetScript("OnClick", function()
		ns.db.templates[currentLang] = nil
		loadTemplates()
	end)

	local resetFilters = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	resetFilters:SetText(L.OPT_RESET_FILTERS)
	resetFilters:SetSize(resetFilters:GetFontString():GetStringWidth() + 30, 24)
	resetFilters:SetPoint("LEFT", resetTemplates, "RIGHT", 8, 0)
	resetFilters:SetScript("OnClick", function()
		ns.FilterBar.ResetFilters()
	end)

	panel:SetScript("OnShow", function()
		currentLang = currentLang or ns.clientLocale
		if not ns.DefaultTemplates[currentLang] then currentLang = "enUS" end
		loadTemplates()
	end)

	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		local ok, cat = pcall(Settings.RegisterCanvasLayoutCategory, panel, L.OPT_TITLE)
		if ok and cat then
			category = cat
			pcall(Settings.RegisterAddOnCategory, cat)
			return
		end
	end
	-- Fallback: standalone window
	panel:SetParent(UIParent)
	panel:SetSize(660, 640)
	panel:SetPoint("CENTER")
	panel:SetFrameStrata("DIALOG")
	panel:EnableMouse(true)
	panel:SetMovable(true)
	panel:RegisterForDrag("LeftButton")
	panel:SetScript("OnDragStart", panel.StartMoving)
	panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
	local bg = panel:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	bg:SetColorTexture(0.05, 0.04, 0.03, 0.95)
	local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", -2, -2)
	tinsert(UISpecialFrames, "BGFOptionsPanel")
	panel:Hide()
end

function Options.Open()
	if not panel then build() end
	if category and Settings and Settings.OpenToCategory then
		local id = category.GetID and category:GetID() or category.ID
		local ok = pcall(Settings.OpenToCategory, id)
		if ok then return end
	end
	panel:Show()
end

-- Register the settings category once the saved variables are ready.
local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
	if not panel then
		local ok, err = pcall(build)
		if not ok then ns.Debug("options build failed: " .. tostring(err)) end
	end
end)
