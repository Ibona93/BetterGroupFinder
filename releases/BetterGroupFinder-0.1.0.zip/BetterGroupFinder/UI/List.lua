local _, ns = ...

--[[
BGF result list: an own ScrollBox laid over Blizzard's list inside LFGBrowseFrame,
using the Group Finder's own textures, fonts and icons. Blizzard's list is not modified,
only hidden while BGF is active.
]]

local List = {}
ns.List = List

local ROW_HEIGHT_COMPACT = 22
local ROW_HEIGHT_NORMAL = 40
local HEADER_HEIGHT = 26
local MESSAGE_HEIGHT = 34
local SLOT_SIZE = 16
local SLOT_GAP = 1
local MAX_SLOTS = 5

local ROLE_ATLAS = {
	TANK = "groupfinder-icon-role-large-tank",
	HEALER = "groupfinder-icon-role-large-heal",
	DAMAGER = "groupfinder-icon-role-large-dps",
}
local ROLE_SORT = { TANK = 1, HEALER = 2, DAMAGER = 3 }
local EXCLUDED_COLOR = { 0.88, 0.63, 0.25 }

List.selectedID = nil
List.NAME_WIDTH_COMPACT = 150

local function classColor(class)
	local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
	if c then return c.r, c.g, c.b end
	return 1, 0.82, 0
end

local function colorize(text, r, g, b)
	return ("|cff%02x%02x%02x%s|r"):format(r * 255, g * 255, b * 255, text or "")
end

local function setAtlasSafe(texture, atlas)
	local ok, result = pcall(texture.SetAtlas, texture, atlas, false)
	return ok and result ~= false
end

-------------------------------------------------------------------------------
-- Role slot widget: class-colored ring + role icon
-------------------------------------------------------------------------------

local function CreateSlot(parent)
	local slot = CreateFrame("Frame", nil, parent)
	slot:SetSize(SLOT_SIZE, SLOT_SIZE)
	slot.Ring = slot:CreateTexture(nil, "BACKGROUND")
	slot.Ring:SetAllPoints()
	slot.Ring:SetColorTexture(1, 1, 1, 1)
	local mask = slot:CreateMaskTexture()
	mask:SetAllPoints(slot.Ring)
	mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
	slot.Ring:AddMaskTexture(mask)
	slot.Icon = slot:CreateTexture(nil, "ARTWORK")
	slot.Icon:SetPoint("CENTER")
	slot.Icon:SetSize(SLOT_SIZE - 3, SLOT_SIZE - 3)
	return slot
end

local function SetSlot(slot, role, class)
	if role then
		setAtlasSafe(slot.Icon, ROLE_ATLAS[role] or ROLE_ATLAS.DAMAGER)
		slot.Icon:SetSize(SLOT_SIZE - 3, SLOT_SIZE - 3)
		if class then
			slot.Ring:SetVertexColor(classColor(class))
			slot.Ring:Show()
		else
			slot.Ring:Hide()
		end
	else
		setAtlasSafe(slot.Icon, "groupfinder-icon-emptyslot")
		slot.Icon:SetSize(SLOT_SIZE - 6, SLOT_SIZE - 6)
		slot.Ring:Hide()
	end
	slot:Show()
end

-------------------------------------------------------------------------------
-- Row
-------------------------------------------------------------------------------

BGFRowMixin = {}

function BGFRowMixin:OnLoad()
	self.ResultBG = self:CreateTexture(nil, "BACKGROUND")
	self.ResultBG:SetPoint("TOPLEFT", 3, -1)
	self.ResultBG:SetPoint("BOTTOMRIGHT", -3, 0)
	if not setAtlasSafe(self.ResultBG, "common-button-list-mid2") then
		self.ResultBG:SetColorTexture(0.1, 0.08, 0.06, 0.8)
	end

	self.Highlight = self:CreateTexture(nil, "HIGHLIGHT")
	self.Highlight:SetPoint("TOPLEFT", 3, -1)
	self.Highlight:SetPoint("BOTTOMRIGHT", -3, 0)
	if not setAtlasSafe(self.Highlight, "common-button-list-mid2-hover") then
		self.Highlight:SetColorTexture(0.3, 0.5, 0.8, 0.15)
	end
	self.Highlight:SetBlendMode("ADD")

	self.Selected = self:CreateTexture(nil, "ARTWORK", nil, -1)
	self.Selected:SetPoint("TOPLEFT", 3, -1)
	self.Selected:SetPoint("BOTTOMRIGHT", -3, 0)
	if not setAtlasSafe(self.Selected, "common-button-list-mid2-selected") then
		self.Selected:SetColorTexture(1, 0.82, 0, 0.15)
	end
	self.Selected:SetBlendMode("ADD")
	self.Selected:Hide()

	self.Icon = self:CreateTexture(nil, "ARTWORK")
	self.Icon:SetSize(14, 14)

	self.Name = self:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	self.Name:SetJustifyH("LEFT")
	self.Name:SetWordWrap(false)

	self.Activity = self:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	self.Activity:SetJustifyH("LEFT")
	self.Activity:SetWordWrap(false)

	self.Style = self:CreateFontString(nil, "ARTWORK", "GameFontGreenSmall")
	self.Style:SetJustifyH("LEFT")
	self.Style:SetWordWrap(false)

	self.NewPlayer = self:CreateTexture(nil, "ARTWORK")
	self.NewPlayer:SetSize(14, 14)
	setAtlasSafe(self.NewPlayer, "newplayerchat-chaticon-newcomer")

	self.Reason = self:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
	self.Reason:SetJustifyH("LEFT")
	self.Reason:SetWordWrap(false)
	self.Reason:SetTextColor(EXCLUDED_COLOR[1], EXCLUDED_COLOR[2], EXCLUDED_COLOR[3])

	self.Score = self:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
	self.Score:SetJustifyH("RIGHT")
	self.Score:SetWidth(28)

	self.Counts = self:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	self.Counts:SetJustifyH("RIGHT")

	self.Slots = {}
	for i = 1, MAX_SLOTS do
		self.Slots[i] = CreateSlot(self)
	end
end

function BGFRowMixin:Layout(compact)
	local slotsWidth = MAX_SLOTS * SLOT_SIZE + (MAX_SLOTS - 1) * SLOT_GAP
	self.Score:ClearAllPoints()
	self.Score:SetPoint("RIGHT", -8, 0)

	-- Slots right-aligned before the score, last slot rightmost.
	for i = MAX_SLOTS, 1, -1 do
		local slot = self.Slots[i]
		slot:ClearAllPoints()
		if i == MAX_SLOTS then
			slot:SetPoint("RIGHT", self.Score, "LEFT", -4, 0)
		else
			slot:SetPoint("RIGHT", self.Slots[i + 1], "LEFT", -SLOT_GAP, 0)
		end
	end
	self.Counts:ClearAllPoints()
	self.Counts:SetPoint("RIGHT", self.Score, "LEFT", -4, 0)
	self.Counts:SetWidth(slotsWidth + 20)

	self.Icon:ClearAllPoints()
	self.Name:ClearAllPoints()
	self.Activity:ClearAllPoints()
	self.Style:ClearAllPoints()
	self.NewPlayer:ClearAllPoints()
	self.Reason:ClearAllPoints()

	if compact then
		self.Icon:SetPoint("LEFT", 8, 0)
		self.Name:SetPoint("LEFT", self.Icon, "RIGHT", 3, 0)
		self.Name:SetWidth(List.NAME_WIDTH_COMPACT)
		self.Style:SetPoint("RIGHT", self.Slots[1], "LEFT", -6, 0)
		self.Style:SetWidth(62)
		self.NewPlayer:SetPoint("RIGHT", self.Style, "LEFT", -2, 0)
		self.Activity:SetPoint("LEFT", self.Name, "RIGHT", 4, 0)
		self.Activity:SetPoint("RIGHT", self.NewPlayer, "LEFT", -2, 0)
		self.Reason:SetPoint("LEFT", self.Name, "RIGHT", 4, 0)
		self.Reason:SetPoint("RIGHT", self.Slots[1], "LEFT", -6, 0)
	else
		self.Icon:SetPoint("TOPLEFT", 8, -5)
		self.Name:SetPoint("LEFT", self.Icon, "RIGHT", 3, 0)
		self.Name:SetPoint("RIGHT", self.Slots[1], "LEFT", -6, 0)
		self.Name:SetWidth(0)
		self.Activity:SetPoint("TOPLEFT", self.Icon, "BOTTOMLEFT", 2, -3)
		self.Activity:SetPoint("RIGHT", self.Slots[1], "LEFT", -100, 0)
		self.Style:SetPoint("LEFT", self.Activity, "RIGHT", 6, 0)
		self.Style:SetWidth(76)
		self.NewPlayer:SetPoint("LEFT", self.Name, "RIGHT", 2, 0)
		self.Reason:SetPoint("TOPLEFT", self.Icon, "BOTTOMLEFT", 2, -3)
		self.Reason:SetPoint("RIGHT", self.Slots[1], "LEFT", -6, 0)
	end
end

local function sortedMembers(members)
	local list = {}
	for _, m in ipairs(members or {}) do list[#list + 1] = m end
	table.sort(list, function(a, b)
		return (ROLE_SORT[a.role or "DAMAGER"] or 3) < (ROLE_SORT[b.role or "DAMAGER"] or 3)
	end)
	return list
end

function BGFRowMixin:Init(data)
	local entry = data.entry
	self.entry = entry
	self.resultID = entry.resultID
	local info = entry.info
	local compact = ns.db.compact
	self:Layout(compact)
	self:SetAlpha(1)

	-- Icon and name
	local leaderClass
	for _, m in ipairs(entry.members or {}) do
		if m.isLeader or entry.isSolo then leaderClass = m.class break end
	end
	if entry.isSolo then
		if not (leaderClass and setAtlasSafe(self.Icon, "groupfinder-icon-class-" .. leaderClass:lower())) then
			setAtlasSafe(self.Icon, "groupfinder-icon-leader")
		end
	else
		setAtlasSafe(self.Icon, "groupfinder-icon-leader")
	end
	local name = info.leaderName or "?"
	if Ambiguate then name = Ambiguate(name, "none") end
	local nameText = colorize(name, classColor(leaderClass))
	if entry.isSolo and entry.members and entry.members[1] and entry.members[1].level then
		nameText = nameText .. " " .. colorize((LEVEL_ABBR or "Lvl") .. " " .. entry.members[1].level, 0.6, 0.6, 0.6)
	end
	self.Name:SetText(nameText)

	-- Activity and play style
	local activity = entry.activityName
	if entry.own then
		activity = LFG_SELF_LISTING or ns.L.OWN_LISTING
	elseif (entry.numActivities or 0) > 1 and LFGBROWSE_ACTIVITY_COUNT then
		activity = activity ~= "" and activity or LFGBROWSE_ACTIVITY_COUNT:format(entry.numActivities)
	end
	self.Activity:SetText(activity or "")
	local style = ""
	if info.generalPlaystyle and GetGeneralPlaystyleString then
		style = GetGeneralPlaystyleString(info.generalPlaystyle) or ""
	end
	self.Style:SetText(style)
	self.NewPlayer:SetShown(info.newPlayerFriendly and true or false)

	-- Members / roles
	for _, slot in ipairs(self.Slots) do slot:Hide() end
	self.Counts:Hide()
	if entry.isSolo then
		local m = entry.members and entry.members[1]
		local roles = m and m.lfgRoles
		local list = {}
		if roles then
			if roles.tank then list[#list + 1] = "TANK" end
			if roles.healer then list[#list + 1] = "HEALER" end
			if roles.dps then list[#list + 1] = "DAMAGER" end
		end
		-- right-align offered roles
		local offset = MAX_SLOTS - #list
		for i, role in ipairs(list) do
			SetSlot(self.Slots[offset + i], role, m.class)
		end
	elseif (entry.maxPlayers or 5) <= MAX_SLOTS then
		local members = sortedMembers(entry.members)
		local maxPlayers = math.min(entry.maxPlayers or MAX_SLOTS, MAX_SLOTS)
		local offset = MAX_SLOTS - maxPlayers
		for i = 1, maxPlayers do
			local m = members[i]
			SetSlot(self.Slots[offset + i], m and (m.role or "DAMAGER"), m and m.class)
		end
	else
		-- Raids: role counts instead of single slots
		local counts = { TANK = 0, HEALER = 0, DAMAGER = 0 }
		for _, m in ipairs(entry.members or {}) do
			counts[m.role or "DAMAGER"] = counts[m.role or "DAMAGER"] + 1
		end
		local parts = {}
		for _, role in ipairs({ "TANK", "HEALER", "DAMAGER" }) do
			local icon = CreateAtlasMarkup and CreateAtlasMarkup(ROLE_ATLAS[role], 12, 12) or role:sub(1, 1)
			parts[#parts + 1] = icon .. counts[role]
		end
		self.Counts:SetText(table.concat(parts, " ") .. "  " .. (info.numMembers or 0) .. "/" .. (entry.maxPlayers or 40))
		self.Counts:Show()
	end

	-- Score / exclusion
	local result = entry.result
	local excluded = data.excluded
	self.Reason:SetShown(excluded)
	self.Activity:SetShown(not excluded)
	self.Style:SetShown(not excluded)
	if excluded then
		self.NewPlayer:Hide()
		self.Reason:SetText(result and result.excludeReason and ns.FormatReason(result.excludeReason) or "")
		self.Score:SetText("")
		self:SetAlpha(0.62)
	elseif result and not entry.own then
		self.Score:SetText((result.score > 0 and "+" or "") .. result.score)
	else
		self.Score:SetText("")
	end
	self:UpdateSelection()
end

function BGFRowMixin:UpdateSelection()
	self.Selected:SetShown(self.resultID ~= nil and self.resultID == List.selectedID)
end

function BGFRowMixin:OnClick(button)
	local entry = self.entry
	if not entry or entry.own then return end
	if button == "RightButton" then
		if LFGBrowseFrame and LFGBrowseFrame.CreateSearchEntryMenu then
			pcall(LFGBrowseFrame.CreateSearchEntryMenu, LFGBrowseFrame, { resultID = entry.resultID })
		end
		return
	end
	if entry.info and entry.info.isDelisted then return end
	if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) end
	if List.selectedID == entry.resultID then
		List.selectedID = nil
	else
		List.selectedID = entry.resultID
	end
	List.UpdateSelections()
	if ns.UI and ns.UI.UpdateButtons then ns.UI.UpdateButtons() end
end

function BGFRowMixin:OnEnter()
	if not self.entry then return end
	if ns.db.debug then ns.Engine.DumpResult(self.entry.resultID) end
	ns.Tooltip.Show(self, self.entry)
end

function BGFRowMixin:OnLeave()
	ns.Tooltip.Hide()
end

-------------------------------------------------------------------------------
-- Header
-------------------------------------------------------------------------------

BGFHeaderMixin = {}

function BGFHeaderMixin:OnLoad()
	self.BG = self:CreateTexture(nil, "BACKGROUND")
	self.BG:SetPoint("TOPLEFT", 3, -4)
	self.BG:SetPoint("BOTTOMRIGHT", -3, 0)
	if not setAtlasSafe(self.BG, "common-button-list-collapseExpand") then
		self.BG:SetColorTexture(0.16, 0.11, 0.07, 0.9)
	end
	self.Label = self:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	self.Label:SetPoint("LEFT", 12, -2)
	self.Count = self:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	self.Count:SetPoint("RIGHT", -34, -2)
	self.Toggle = self:CreateTexture(nil, "ARTWORK")
	self.Toggle:SetPoint("RIGHT", -12, -2)
	self.Highlight = self:CreateTexture(nil, "HIGHLIGHT")
	self.Highlight:SetAllPoints(self.BG)
	if not setAtlasSafe(self.Highlight, "common-button-list-collapseExpand") then
		self.Highlight:SetColorTexture(1, 1, 1, 0.05)
	end
	self.Highlight:SetBlendMode("ADD")
end

function BGFHeaderMixin:Init(data)
	self.key = data.key
	self.Label:SetText(data.label)
	self.Count:SetText(data.count or "")
	local collapsed = ns.db.collapsed[data.key]
	local atlas = collapsed and "common-button-list-plus" or "common-button-list-minus"
	if setAtlasSafe(self.Toggle, atlas) then
		self.Toggle:SetSize(14, 14)
	end
	if data.key == "excluded" then
		self.Label:SetTextColor(0.66, 0.6, 0.53)
	else
		self.Label:SetTextColor(1, 0.82, 0)
	end
end

function BGFHeaderMixin:OnClick()
	ns.db.collapsed[self.key] = not ns.db.collapsed[self.key]
	if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) end
	List.Render()
end

-------------------------------------------------------------------------------
-- Message line
-------------------------------------------------------------------------------

BGFMessageMixin = {}

function BGFMessageMixin:OnLoad()
	self.Text = self:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
	self.Text:SetPoint("LEFT", 12, 0)
	self.Text:SetPoint("RIGHT", -12, 0)
	self.Text:SetJustifyH("LEFT")
	self.Text:SetTextColor(EXCLUDED_COLOR[1], EXCLUDED_COLOR[2], EXCLUDED_COLOR[3])
end

function BGFMessageMixin:Init(data)
	self.Text:SetText(data.text)
end

-------------------------------------------------------------------------------
-- List frame
-------------------------------------------------------------------------------

function List.Create(parent)
	local scrollBox = CreateFrame("Frame", nil, parent, "WowScrollBoxList")
	local scrollBar = CreateFrame("EventFrame", nil, parent, "MinimalScrollBar")
	scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, -4)
	scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 2)

	local view = CreateScrollBoxListLinearView()
	view:SetElementFactory(function(factory, data)
		if data.kind == "header" then
			factory("BGFHeaderTemplate", function(frame, d) frame:Init(d) end)
		elseif data.kind == "message" then
			factory("BGFMessageTemplate", function(frame, d) frame:Init(d) end)
		else
			factory("BGFRowTemplate", function(frame, d) frame:Init(d) end)
		end
	end)
	view:SetElementExtentCalculator(function(_, data)
		if data.kind == "header" then return HEADER_HEIGHT end
		if data.kind == "message" then return MESSAGE_HEIGHT end
		return ns.db.compact and ROW_HEIGHT_COMPACT or ROW_HEIGHT_NORMAL
	end)
	ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, view)

	List.scrollBox = scrollBox
	List.scrollBar = scrollBar
	List.view = view
	return scrollBox, scrollBar
end

function List.SetShown(shown)
	if not List.scrollBox then return end
	List.scrollBox:SetShown(shown)
	List.scrollBar:SetShown(shown)
end

function List.UpdateSelections()
	if not List.scrollBox then return end
	List.scrollBox:ForEachFrame(function(frame)
		if frame.UpdateSelection then frame:UpdateSelection() end
	end)
end

function List.GetSelectedEntry()
	if not List.selectedID or not List.sections then return nil end
	for _, key in ipairs({ "groups", "players", "excluded", "own" }) do
		for _, entry in ipairs(List.sections[key] or {}) do
			if entry.resultID == List.selectedID then return entry end
		end
	end
	return nil
end

-- Builds the flat element list from the current sections and shows it.
function List.SetSections(sections)
	List.sections = sections
	if List.selectedID and not List.GetSelectedEntry() then
		List.selectedID = nil
	end
	List.Render()
end

function List.Render()
	if not List.scrollBox then return end
	local sections = List.sections
	local L = ns.L
	local items = {}
	if sections then
		if ns.Engine.locked then
			items[#items + 1] = { kind = "message", text = L.LOCKDOWN }
		end
		for _, entry in ipairs(sections.own) do
			items[#items + 1] = { kind = "row", entry = entry }
		end
		local shown = #sections.groups + #sections.players
		if sections.total > 0 and shown == 0 and #sections.own == 0 and #sections.excluded > 0 then
			items[#items + 1] = { kind = "message", text = L.ALL_EXCLUDED:format(#sections.excluded) }
		end
		local function addSection(key, label, list, excluded)
			if #list == 0 then return end
			items[#items + 1] = {
				kind = "header", key = key, label = label,
				count = excluded and #list or L.MATCHING:format(#list),
			}
			if not ns.db.collapsed[key] then
				for _, entry in ipairs(list) do
					items[#items + 1] = { kind = "row", entry = entry, excluded = excluded }
				end
			end
		end
		addSection("groups", L.GROUPS, sections.groups, false)
		addSection("players", L.PLAYERS, sections.players, false)
		addSection("excluded", L.EXCLUDED, sections.excluded, true)
	end
	local provider = CreateDataProvider(items)
	List.scrollBox:SetDataProvider(provider, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
end
