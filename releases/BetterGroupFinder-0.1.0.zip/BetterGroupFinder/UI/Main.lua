local _, ns = ...

--[[
UI wiring inside Blizzard's Group Finder (LFGParentFrame / LFGBrowseFrame):
  * BGF list over Blizzard's list (Blizzard's list and footer buttons hidden while active)
  * filter button next to Refresh, filter bar under the header
  * "Request" button between "Send Message" and "Group Invite"
  * resize grip in the lower right corner (scales the whole window, out of combat only)
Nothing of Blizzard's code is replaced; BGF only hooks, reads and shows/hides.
]]

local UI = {}
ns.UI = UI

local EXTRA_WIDTH = 140       -- extra width while the BGF list is shown
local LIST_TOP = -112          -- Blizzard's list top offset in LFGBrowseFrame
local LIST_BOTTOM = 40
local FILTER_TOP = -84
local MIN_SCALE, MAX_SCALE = 0.6, 1.6

local base = {}               -- original width/height of LFGParentFrame
local pendingLayout = false

local function inCombat()
	return InCombatLockdown and InCombatLockdown()
end

-------------------------------------------------------------------------------
-- Blizzard list visibility
-------------------------------------------------------------------------------

local function bgfActive()
	return ns.db.enabled and LFGBrowseFrame and LFGBrowseFrame:IsShown()
end

local function setBlizzardListShown(shown)
	local f = LFGBrowseFrame
	if not f then return end
	for _, child in ipairs({ f.ScrollBox, f.ScrollBar, f.SendMessageButton, f.GroupInviteButton }) do
		if child then
			if shown then child:Show() else child:Hide() end
		end
	end
	if shown and f.ScrollBar and f.ScrollBox and f.ScrollBox.HasScrollableExtent then
		local ok, scrollable = pcall(f.ScrollBox.HasScrollableExtent, f.ScrollBox)
		if ok and not scrollable then f.ScrollBar:Hide() end
	end
end

local function keepHiddenWhileActive(frame)
	if frame and frame.HookScript then
		frame:HookScript("OnShow", function(self)
			if ns.db.enabled then self:Hide() end
		end)
	end
end

-------------------------------------------------------------------------------
-- Layout: width, height (filter bar), scale
-------------------------------------------------------------------------------

function UI.ApplyLayout()
	local parent = LFGParentFrame
	if not parent or not base.width then return end
	local bar = ns.FilterBar.frame
	local open = ns.db.filterOpen and ns.db.enabled and LFGBrowseFrame:IsShown()
	local combat = inCombat()
	pendingLayout = combat

	if not combat then
		local wide = ns.db.enabled and LFGBrowseFrame:IsShown()
		parent:SetWidth(base.width + (wide and EXTRA_WIDTH or 0))
	end

	local barHeight = 0
	if open then
		bar:ClearAllPoints()
		bar:SetPoint("TOPLEFT", LFGBrowseFrame, "TOPLEFT", 8, FILTER_TOP)
		bar:SetPoint("TOPRIGHT", LFGBrowseFrame, "TOPRIGHT", -8, FILTER_TOP)
		bar:Show()
		barHeight = ns.FilterBar.Layout()
		bar:SetHeight(barHeight)
		ns.FilterBar.Update()
	else
		bar:Hide()
	end

	if not combat then
		parent:SetHeight(base.height + barHeight)
	end

	local scrollBox = ns.List.scrollBox
	scrollBox:ClearAllPoints()
	scrollBox:SetPoint("TOPLEFT", LFGBrowseFrame, "TOPLEFT", 7, LIST_TOP - barHeight)
	scrollBox:SetPoint("BOTTOMRIGHT", LFGBrowseFrame, "BOTTOMRIGHT", -24, LIST_BOTTOM)
end

function UI.ApplyScale()
	if not LFGParentFrame then return end
	if inCombat() then pendingLayout = true return end
	local scale = math.min(MAX_SCALE, math.max(MIN_SCALE, ns.db.scale or 1))
	LFGParentFrame:SetScale(scale)
end

function UI.OnCombatStart()
	if UI.grip and UI.grip.dragging then
		UI.grip.dragging = false
		UI.grip:SetScript("OnUpdate", nil)
	end
end

function UI.OnCombatEnd()
	if pendingLayout then
		UI.ApplyScale()
		UI.ApplyLayout()
	end
end

-------------------------------------------------------------------------------
-- Enable / disable
-------------------------------------------------------------------------------

function UI.ApplyEnabled()
	if not UI.attached then return end
	local enabled = ns.db.enabled
	setBlizzardListShown(not enabled)
	ns.List.SetShown(enabled)
	UI.messageButton:SetShown(enabled)
	UI.inviteButton:SetShown(enabled)
	UI.ApplyLayout()
	ns.FilterBar.Update()
	if enabled then ns.RequestRefresh() end
	UI.UpdateButtons()
end

-------------------------------------------------------------------------------
-- Selection and footer buttons
-------------------------------------------------------------------------------

local function blizzardSelectedID()
	local f = LFGBrowseFrame
	if not f or not f.selectionBehavior then return nil end
	local ok, has = pcall(f.selectionBehavior.HasSelection, f.selectionBehavior)
	if not ok or not has then return nil end
	local okData, data = pcall(f.selectionBehavior.GetSelectedElementData, f.selectionBehavior)
	local element = okData and data and data[1]
	return element and element.data and element.data.resultID
end

function UI.GetSelectedEntry()
	if ns.db.enabled then
		return ns.List.GetSelectedEntry()
	end
	local id = blizzardSelectedID()
	if not id then return nil end
	return ns.Engine.EvaluateResult(id, ns.Engine.GetMySide())
end

function UI.UpdateButtons()
	if not UI.attached then return end
	local entry = UI.GetSelectedEntry()
	local valid = entry and not entry.own and entry.info and not entry.info.isDelisted
	UI.requestButton:SetEnabled(valid and true or false)
	UI.messageButton:SetEnabled(valid and true or false)
	local canInvite = valid and entry.isSolo and ns.Contact.Mode(entry) == "invite"
	UI.inviteButton:SetEnabled(canInvite and true or false)
end

local function createFooter()
	local f = LFGBrowseFrame
	local L = ns.L

	UI.messageButton = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	UI.messageButton:SetSize(111, 28)
	UI.messageButton:SetPoint("BOTTOMLEFT", 21, 16)
	UI.messageButton:SetText(SEND_MESSAGE or "Send Message")
	UI.messageButton:SetScript("OnClick", function()
		local entry = UI.GetSelectedEntry()
		if entry and entry.info and entry.info.leaderName and ChatFrameUtil and ChatFrameUtil.SendTell then
			ChatFrameUtil.SendTell(entry.info.leaderName)
		end
	end)

	UI.inviteButton = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	UI.inviteButton:SetSize(109, 28)
	UI.inviteButton:SetPoint("BOTTOMRIGHT", -21, 16)
	UI.inviteButton:SetText(GROUP_INVITE or "Group Invite")
	UI.inviteButton:SetScript("OnClick", function()
		local entry = UI.GetSelectedEntry()
		if entry and entry.info and entry.info.leaderName and C_PartyInfo and C_PartyInfo.InviteUnit then
			pcall(C_PartyInfo.InviteUnit, entry.info.leaderName)
		end
	end)

	UI.requestButton = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	UI.requestButton:SetSize(100, 28)
	UI.requestButton:SetPoint("BOTTOM", 0, 16)
	UI.requestButton:SetText(L.REQUEST)
	UI.requestButton:SetScript("OnClick", function(self)
		ns.Contact.OpenMenu(self, UI.GetSelectedEntry())
	end)
	UI.requestButton:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L.REQUEST, 1, 1, 1)
		GameTooltip:AddLine(L.REQUEST_TT, nil, nil, nil, true)
		GameTooltip:Show()
	end)
	UI.requestButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-------------------------------------------------------------------------------
-- Header filter button
-------------------------------------------------------------------------------

local function createFilterButton()
	local f = LFGBrowseFrame
	local L = ns.L
	local b = CreateFrame("Button", nil, f)
	b:SetSize(32, 32)
	if f.RefreshButton then
		b:SetPoint("LEFT", f.RefreshButton, "RIGHT", 2, 0)
	else
		b:SetPoint("TOPRIGHT", -40, -36)
	end
	b:SetNormalTexture("Interface\\Buttons\\UI-SquareButton-Up")
	b:SetPushedTexture("Interface\\Buttons\\UI-SquareButton-Down")
	b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	b.Icon = b:CreateTexture(nil, "ARTWORK", nil, 5)
	b.Icon:SetPoint("CENTER", -1, 0)
	b.Icon:SetSize(16, 16)
	local ok = pcall(b.Icon.SetAtlas, b.Icon, "ui-questtrackerbutton-filter", false)
	if not ok then b.Icon:SetTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Up") end
	b.Active = b:CreateTexture(nil, "OVERLAY")
	b.Active:SetAllPoints()
	b.Active:SetTexture("Interface\\Buttons\\CheckButtonHilight")
	b.Active:SetBlendMode("ADD")
	b:SetScript("OnClick", function()
		if inCombat() then ns.Print(L.COMBAT_FILTER) return end
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) end
		ns.db.filterOpen = not ns.db.filterOpen
		if ns.db.filterOpen and not ns.db.enabled then
			ns.db.enabled = true
			UI.ApplyEnabled()
		end
		UI.ApplyLayout()
		UI.UpdateFilterButton()
	end)
	b:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(L.FILTER_BUTTON_TT, 1, 1, 1)
		GameTooltip:AddLine(L.FILTER_BUTTON_TT2, nil, nil, nil, true)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	UI.filterButton = b
end

function UI.UpdateFilterButton()
	if UI.filterButton then UI.filterButton.Active:SetShown(ns.db.filterOpen) end
end

-------------------------------------------------------------------------------
-- Resize grip
-------------------------------------------------------------------------------

local function createGrip()
	local L = ns.L
	local g = CreateFrame("Button", nil, LFGBrowseFrame)
	g:SetSize(16, 16)
	g:SetPoint("BOTTOMRIGHT", -5, 5)
	g:SetFrameLevel(LFGBrowseFrame:GetFrameLevel() + 20)
	g:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
	g:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
	g:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
	g:RegisterForClicks("RightButtonUp")

	g:SetScript("OnMouseDown", function(self, button)
		if button ~= "LeftButton" then return end
		if inCombat() then ns.Print(L.COMBAT_RESIZE) return end
		local parent = LFGParentFrame
		local eff = parent:GetEffectiveScale()
		self.startScale = parent:GetScale()
		self.left = parent:GetLeft() * eff
		self.top = parent:GetTop() * eff
		self.width = parent:GetWidth() * eff
		self.height = parent:GetHeight() * eff
		self.dragging = true
		self:SetScript("OnUpdate", function(s)
			if not s.dragging then return end
			if inCombat() then UI.OnCombatStart() return end
			local x, y = GetCursorPosition()
			local ratio = math.max((x - s.left) / s.width, (s.top - y) / s.height)
			local scale = math.min(MAX_SCALE, math.max(MIN_SCALE, s.startScale * ratio))
			LFGParentFrame:SetScale(scale)
		end)
	end)
	g:SetScript("OnMouseUp", function(self, button)
		if button ~= "LeftButton" or not self.dragging then return end
		self.dragging = false
		self:SetScript("OnUpdate", nil)
		ns.db.scale = LFGParentFrame:GetScale()
	end)
	g:SetScript("OnClick", function()
		if inCombat() then ns.Print(L.COMBAT_RESIZE) return end
		ns.db.scale = 1
		UI.ApplyScale()
	end)
	g:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(L.RESIZE_TT, 1, 1, 1)
		GameTooltip:AddLine(L.RESIZE_TT2, nil, nil, nil, true)
		GameTooltip:Show()
	end)
	g:SetScript("OnLeave", function() GameTooltip:Hide() end)
	UI.grip = g
end

-------------------------------------------------------------------------------
-- Refresh
-------------------------------------------------------------------------------

function UI.Refresh()
	if not UI.attached or not LFGBrowseFrame then return end
	if ns.FilterBar.frame and ns.FilterBar.frame:IsShown() then ns.FilterBar.Update() end
	if not bgfActive() then
		UI.UpdateButtons()
		return
	end
	setBlizzardListShown(false)
	local f = LFGBrowseFrame
	if f.searching then
		ns.List.SetSections(nil)
	else
		local results = f.results
		if type(results) ~= "table" then
			local ok, _, filtered = false, nil, nil
			if C_LFGList and C_LFGList.GetFilteredSearchResults then ok, _, filtered = pcall(C_LFGList.GetFilteredSearchResults) end
			results = ok and filtered or {}
		end
		if f.searchFailed or (f.totalResults or 0) == 0 then results = {} end
		ns.List.SetSections(ns.Engine.BuildSections(results))
	end
	UI.UpdateButtons()
end

-------------------------------------------------------------------------------
-- Setup
-------------------------------------------------------------------------------

function UI.Setup()
	if UI.attached or not LFGBrowseFrame or not LFGParentFrame then return end
	base.width, base.height = LFGParentFrame:GetWidth(), LFGParentFrame:GetHeight()

	ns.List.Create(LFGBrowseFrame)
	ns.FilterBar.Create(LFGBrowseFrame)
	createFooter()
	createFilterButton()
	createGrip()
	UI.attached = true

	keepHiddenWhileActive(LFGBrowseFrame.ScrollBox)
	keepHiddenWhileActive(LFGBrowseFrame.ScrollBar)
	keepHiddenWhileActive(LFGBrowseFrame.SendMessageButton)
	keepHiddenWhileActive(LFGBrowseFrame.GroupInviteButton)

	if LFGBrowseFrame.UpdateResults then
		hooksecurefunc(LFGBrowseFrame, "UpdateResults", function() ns.RequestRefresh() end)
	end
	if LFGBrowseFrame.UpdateButtonState then
		hooksecurefunc(LFGBrowseFrame, "UpdateButtonState", function() UI.UpdateButtons() end)
	end
	LFGBrowseFrame:HookScript("OnShow", function()
		UI.ApplyLayout()
		ns.RequestRefresh()
	end)
	LFGBrowseFrame:HookScript("OnHide", function()
		ns.Tooltip.Hide()
		UI.ApplyLayout()
	end)
	LFGParentFrame:HookScript("OnShow", function()
		UI.ApplyScale()
	end)
	if LFGBrowseFrame.CategoryDropdown and LFGBrowseFrame.CategoryDropdown.HookScript then
		pcall(hooksecurefunc, LFGBrowseFrame.CategoryDropdown, "SetValue", function() ns.FilterBar.Update() end)
	end

	UI.ApplyScale()
	UI.ApplyEnabled()
	UI.UpdateFilterButton()
	ns.Debug("UI attached")
end
