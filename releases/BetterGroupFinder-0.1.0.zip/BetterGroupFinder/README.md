# Better Group Finder (BGF) 0.1.0 – WoW Forever

Erweiterung für den Gruppenfinder von WoW Forever:
- intelligente Filter
- Bewertung der Gruppenzusammensetzung
- Nachrichtenvorlagen mit automatischem Versand
- kompakte, frei skalierbare Ansicht

Ziel-Version: WoW Forever **1.60.1, Interface 16001** (Beta-Stand 9. Oktober 2026).

---

## 1. Installation

1. Das Spiel schließen (oder später `/reload` eingeben).
2. Das ZIP entpacken. Heraus kommt der Ordner `BetterGroupFinder`.
3. Den Ordner in den AddOns-Ordner des Forever-Clients kopieren. In der Beta ist das:
   `World of Warcraft\_classic_beta_\Interface\AddOns\BetterGroupFinder`
   Nach dem Release heißt der Client-Ordner voraussichtlich anders. Entscheidend ist der Ordner, aus dem du Forever startest.
4. Der Ordner muss direkt `BetterGroupFinder.toc` enthalten. Ein Ordner `BetterGroupFinder\BetterGroupFinder\…` funktioniert nicht.
5. Im Charakterauswahl-Bildschirm unter **AddOns** „Better Group Finder“ aktivieren.
6. Empfohlen für die ersten Tests: **BugSack + BugGrabber** installieren, damit eventuelle Lua-Fehler gesammelt werden.

Falls das Spiel das Addon als „veraltet“ markiert, hat sich nach einem Patch die Interface-Nummer geändert. Prüfen mit `/dump (select(4, GetBuildInfo()))` und die Zahl in der ersten Zeile der `.toc` anpassen.

---

## 2. Funktionen im Überblick

| Bereich | Was BGF macht |
|---|---|
| Ergebnisliste | Eigene Liste im Gruppenfinder-Fenster in Blizzards Optik. Bereiche: **Gruppen**, **Spieler**, **Aussortiert** (eingeklappt, mit Begründung). Sortiert nach BGF-Punkten. |
| Kompakte Ansicht | Ein Eintrag = eine Zeile. Name (+ Stufe), Instanz, Spielstil, „Neue Spieler willkommen“, Rollen, Punkte. Jedes Rollen-Icon hat einen Ring in Klassenfarbe: Rolle und Klasse sind ohne Hovern sichtbar. Bei Schlachtzügen erscheinen Rollenzahlen statt Einzel-Icons. |
| Normale Ansicht | Zweizeilig, gleiche Informationen. |
| Fensterbreite | Solange die BGF-Liste angezeigt wird, ist das Fenster 140 px breiter, damit nichts abgeschnitten wird. Auf den anderen Reitern hat es die Originalbreite. |
| Fenstergröße | Greifpunkt unten rechts: ziehen skaliert das ganze Fenster samt Inhalt (60–160 %). Rechtsklick setzt auf 100 % zurück. **Nur außerhalb des Kampfes.** Die Größe wird gespeichert. |
| Filterleiste | Trichter-Button neben „Aktualisieren“. Die Leiste klappt unter dem Header auf, und das Fenster wird dabei **länger**, die Liste behält ihre Höhe. Öffnen und Schließen nur außerhalb des Kampfes. |
| Bewertung | Automatisch aus deiner Sicht: solo „passe ich rein?“, in einer Gruppe „passt der zu uns?“. Zwei Gruppen werden auf einen Zusammenschluss geprüft. |
| Tooltip | Blizzards Tooltip (Mitglieder, Voicechat, Aktivität) plus darunter die BGF-Begründung: grün = Vorteil, rot = Abzug, grau = Lücke, orange = Ausschlussgrund. |
| Anfrage-Button | Neuer Button im Footer zwischen „Nachricht senden“ und „Gruppeneinladung“. Er öffnet die Vorlagenauswahl, und ein Klick **sendet sofort**. |
| Rechtsklick auf Eintrag | Blizzards eigenes Kontextmenü (Nachricht, Einladen, Melden). |
| Sprachen | Oberfläche in allen 11 Clientsprachen, Vorlagen ebenso. |
| Ein/Aus | Häkchen in der Filterleiste oder `/bgf off`. Dann erscheint wieder Blizzards Originalliste. |

---

## 3. Bedienung

### Filterleiste
- **BGF-Filter aktiv:** schaltet die BGF-Liste ein oder aus.
- **Bewertung für:** zeigt die Perspektive („Du · Jäger St. 22 (DPS)“ oder „Deine Gruppe (3)“).
- **Profil:** folgt der Kategorie (Dungeons, Schlachtzüge, sonstige). Jedes Profil hat eigene Fähigkeiten-Einstellungen.
- **Freier Platz für / Gesucht:** wird automatisch gesetzt.
  - Solo zeigt diese Zeile deine im Gruppenfinder gewählten Rollen, in einer Gruppe die fehlenden Rollen.
  - Ein Klick wechselt auf manuelle Auswahl. „Filter zurücksetzen“ in den Optionen stellt wieder auf automatisch.
- **Fähigkeiten:** Ein Klick wechselt zwischen *egal (grau)*, *bevorzugt (weiß)* und *benötigt (gold)*.
- **Ansicht:** Normal oder Kompakt.

### Anfrage-Button
Der Button verhält sich je nach Auswahl unterschiedlich:

| Auswahl | Was passiert |
|---|---|
| Gruppe, du bist solo | Beitrittsanfrage an den Gruppenleiter |
| Gruppe, du bist in einer Gruppe | Anfrage als Gruppe (Zusammenschluss) |
| Einzelspieler, du darfst einladen | Einladung **und** Einladungsnachricht |

Im Menü stehen zuerst deine Spielsprache, darunter Englisch, dann „Weitere Sprachen“ mit den Sprachen deiner Region. Wer mit der Maus über einen Eintrag fährt, sieht den fertigen Text vorab.

Ist der Chat gerade gesperrt (Kampf in Instanzen) oder schlägt das Senden fehl, steht der Text stattdessen fertig im Chatfenster. Dann genügt Enter.

### Befehle
| Befehl | Wirkung |
|---|---|
| `/bgf` | Optionen öffnen (Vorlagen bearbeiten, Schalter) |
| `/bgf on` / `/bgf off` | BGF-Liste ein/aus |
| `/bgf reset` | Fenstergröße auf 100 % |
| `/bgf debug` | Debug-Ausgabe an/aus. Beim Hovern über einen Eintrag werden dessen Rohdaten (inkl. `mapID`, Spezialisierung) in den Chat geschrieben. |

### Vorlagen
Zu finden unter **Optionen → AddOns → Better Group Finder** oder über `/bgf`.

- Pro Sprache gibt es sechs Vorlagen: Beitrittsanfrage, Anfrage als Gruppe und Einladung, jeweils freundlich und kurz.
- Eine geänderte Vorlage wird gespeichert. Ein leeres Feld oder „zurücksetzen“ stellt den Standard wieder her.
- Platzhalter:

| Platzhalter | Wird ersetzt durch |
|---|---|
| `{name}` | Empfänger |
| `{me}` | deinen Namen |
| `{class}` | deine Klasse (in der Sprache der Vorlage) |
| `{role}` | deine Rolle |
| `{level}` | deine Stufe |
| `{instance}` | die Aktivität (Name aus dem Spiel, also in deiner Clientsprache) |
| `{group}` | deine Gruppe, z. B. „Krieger (Tank), Priester (Heiler)“ |

---

## 4. Filter- und Bewertungslogik

Die Logik liegt in `Logic/Scoring.lua` und ist reines Lua ohne Spiel-API (offline getestet).

**Wer ist Gastgeber, wer Gast?** Die größere Seite ist der Gastgeber, bei Gleichstand deine.
- Solo vs. Gruppe: Die Gruppe nimmt dich auf.
- Deine Gruppe vs. Einzelspieler: Ihr nehmt ihn auf.
- Gruppe vs. Gruppe: Zusammenschluss.

**Rollenziele:**
- Dungeon (5er): 1 Tank / 1 Heiler / 3 DPS, **streng**. Überzählige Rollen werden aussortiert.
- Schlachtzug:
  - 10er: 2 / 3 / 5
  - 20er: 3 / 5 / 12
  - 40er: 4 / 10 / 26
  - Andere Größen werden anteilig skaliert. Überzählige Rollen geben nur Abzug.
- Quests & Zonen / Benutzerdefiniert: keine Rollenziele.

Spieler mit mehreren angebotenen Rollen bekommen zuerst einen freien Tank- oder Heilerplatz (knappe Rollen), dann DPS.

**Punkte:**

| Faktor | Punkte |
|---|---|
| Füllt fehlenden Tank / Heiler | +40 |
| Füllt fehlenden DPS-Platz | +20 |
| Bringt fehlende Fähigkeit | + Gewicht (×1,5 bei „benötigt“, ×1,5 bei Instanz-Hinweis) |
| Fähigkeit nur „möglich“ (Talent/Begleiter/Schild/Kreaturtyp) | + halbes Gewicht |
| Gruppe wäre vollständig | +10 |
| Zusammenschluss möglich | +5 |
| Weitere gleiche Klasse ohne neuen Nutzen | −10 (Schlachtzug −5) |
| Kein neuer Nutzen | −5 (Schlachtzug −2) |
| Stufe außerhalb der Empfehlung | −8 |
| Überzählige Rolle im Schlachtzug | −8 |
| „Benötigt“ fehlt noch, aber es sind Plätze frei | − halbes Gewicht |

**Gewichte der Fähigkeiten:**

| Fähigkeit | Gewicht |
|---|---|
| Kontrolle | 10 |
| Unterbrechen | 8 |
| Beschwören | 7 (keine Versammlungssteine in Forever) |
| Fluch entfernen, Magie bannen, Kampfwiederbelebung | 6 |
| Gift heilen, Krankheit heilen | 5 |
| Gesundheitssteine, Furchtschutz, Ausdauer, Mal der Wildnis | 3 |
| Intelligenz, Angriffskraft | 2 |

**Aussortiert** (in den Bereich „Aussortiert“, nie unsichtbar) werden:
- zu viele Spieler zusammen
- kein Platz für die Rolle (mit Angabe, welche Rolle noch gesucht wird)
- Rolle nicht gesucht (manuelle Rollen-Auswahl)
- eine *benötigte* Fähigkeit fehlt, und es ist kein Platz mehr frei
- Stufe unter der Mindeststufe der Aktivität
- passt nicht zum Aktivitätsfilter, nicht mehr gelistet
- **0 Punkte oder weniger** („Kein echter Mehrwert“)

Werden alle Treffer aussortiert, erscheint oben der Hinweis „Alle X Treffer wurden aussortiert – Filter lockern?“.

**Fähigkeiten:**
- Eigener Charakter: BGF prüft dein Zauberbuch. Das gilt aber nur, wenn die Klassik-Spell-IDs in Forever erkannt werden. Sonst fällt BGF auf Klasse + Stufe zurück, siehe `/bgf debug` → „spellbook check“.
- Andere Spieler: Klasse + Stufe. Talentabhängiges gilt als „möglich“.
- Eine vorhandene Fähigkeit wird nicht noch einmal als fehlend oder als Vorteil gezählt.

**Instanz-Hinweise** (`Data/Profiles.lua`): Für bekannte Instanzen werden bestimmte Fähigkeiten höher gewichtet und auch dann berücksichtigt, wenn sie auf „egal“ stehen. Beispiele sind Gift und Magie in den Höhlen des Wehklagens oder Krankheit und Fluch in Stratholme. Neue Forever-Instanzen kannst du dort ergänzen. Die `mapID` liefert `/bgf debug`.

**Unbekannte Daten:**
- Fehlen Klasse oder Rolle, wird das als „? …“ gekennzeichnet und nicht geraten.
- Sind die Mitgliederdaten gesperrt (Chat-Sperre im Kampf in Instanzen), zeigt BGF das als Hinweis an und bewertet erst danach wieder.

---

## 5. Bekannte Einschränkungen

- **Nicht im Spiel getestet.** BGF wurde gegen Blizzards veröffentlichten Forever-UI-Code (1.60.1) und die offizielle API-Dokumentation gebaut, aber ohne Client. Siehe Abschnitt 6.
- **Sprache des Gegenübers** liefert die API nicht. Darum wählst du die Vorlagensprache im Menü.
- **Spezialisierung und Talente** fremder Spieler sind nicht verfügbar. Talentabhängige Fähigkeiten zählen deshalb nur als „möglich“.
- **Fähigkeitentabelle** (`Data/Abilities.lua`): Lernstufen und Spell-IDs stammen aus WoW Classic.
  - Verifiziert für Forever ist nur: kein Kampfrausch/Heldentum, Furchtschutz für alle Priester ab 20.
  - Nach Klassenpatches muss die Tabelle eventuell angepasst werden.
- **Instanz-Hinweise** nutzen Klassik-`mapID`s. Ob Forever dieselben verwendet, zeigt `/bgf debug`.
- **Sprachen außer Deutsch/Englisch** sind von mir übersetzt und sollten vor einer Veröffentlichung von Muttersprachlern geprüft werden.
- **Fenster skalieren/verbreitern** ändert Größe und Skalierung von Blizzards Fenster. Das passiert nur außerhalb des Kampfes, um Taint zu vermeiden. Siehe Taint-Test unten.
- **Die Suche** selbst startet BGF nie. Sie bleibt geschützt und läuft über Blizzards Aktualisieren-Button.
- **Einladen** ist wie bei Blizzard nur für Einzelspieler möglich. Gruppen erreicht man über die Anfrage an den Leiter.
- **Regionssprachen:** In der Beta (ein globaler Server) bzw. bei unbekannter Region zeigt BGF alle Sprachen.

---

## 6. Tests

### Durchgeführt (ohne Spielclient)

| Test | Umfang | Ergebnis |
|---|---|---|
| `luacheck` (Lua 5.1) | alle 24 Dateien | 0 Warnungen, 0 Fehler |
| `tests/run.lua` | Bewertungslogik, Szenarien 1–7 und 12, Pflicht-Fähigkeiten, Stufen, Rollenwahl, Instanz-Hinweise, fehlende/gesperrte API; Vollständigkeit aller 11 Sprachdateien | 60/60 bestanden |
| `tests/smoke.lua` | komplettes Addon in TOC-Reihenfolge mit nachgebildeter WoW-Oberfläche: Laden, Events, Liste mit Daten wie in den Beta-Screenshots, Aussortieren, Filterleiste (Fenster wächst), Fähigkeiten-/Rollenchips, Ansicht, Auswahl, Anfrage-Menü, Platzhalter, automatisches Senden, Fallback bei Chat-Sperre, Einladen + Nachricht, Tooltip, Greifpunkt, keine Größenänderung im Kampf, `/bgf`-Befehle | alle bestanden |

Die Tests lassen sich mit Lua 5.1 erneut ausführen: `lua tests/run.lua` und `lua tests/smoke.lua` aus dem Addon-Ordner.

### Nur konzeptionell geprüft, bitte im Spiel testen

Vorher `/console taintLog 1` eingeben. Nach dem Test liegt die Datei `Logs\taint.log` im Client-Ordner.

| # | Test | Erwartung |
|---|---|---|
| 1 | Gruppenfinder öffnen → Suche → Dungeons | BGF-Liste in Blizzard-Optik, Fenster etwas breiter |
| 2 | Trichter-Button | Filterleiste klappt auf, Fenster wird länger, Liste gleich hoch |
| 3 | Fähigkeit auf „benötigt“ stellen | Treffer ohne diese Fähigkeit rutschen nach unten bzw. zu „Aussortiert“ |
| 4 | Kompakt ↔ Normal | Zeilen wechseln, nichts überlappt, Texte lesbar |
| 5 | Greifpunkt ziehen | Fenster skaliert, Text bleibt scharf; nach `/reload` gleiche Größe |
| 6 | Im Kampf ziehen | Hinweis, keine Änderung |
| 7 | Eintrag hovern | Blizzard-Tooltip + BGF-Begründung darunter |
| 8 | Gruppe wählen → Anfrage → Freundlich | Flüsternachricht wird gesendet, Platzhalter korrekt |
| 9 | Als Gruppenleiter Einzelspieler → Anfrage | Einladung + Nachricht |
| 10 | `/bgf off` und `/bgf on` | Originalliste bzw. BGF-Liste |
| 11 | Nach dem Test: Dungeon betreten, kämpfen, Aktionsleisten benutzen | keine „Aktion blockiert“-Meldungen. `taint.log` nach `BetterGroupFinder` durchsuchen und mir schicken, falls Einträge auftauchen |
| 12 | `/bgf debug`, über Einträge fahren | Rohdaten erscheinen. Bitte prüfen, ob `spec` gefüllt ist und welche `mapID` die Forever-Instanzen haben |

Fehlermeldungen (BugSack) und Auffälligkeiten bitte mit Screenshot melden.

---

## 7. Dateien

```
BetterGroupFinder.toc   Interface 16001, SavedVariables BetterGroupFinderDB
Init.lua                Namensraum, Hilfsfunktionen, Sprachlisten
Locales/*.lua           11 Sprachen: Oberfläche, Klassen-/Rollenwörter, Standardvorlagen
Data/Abilities.lua      Fähigkeiten je Klasse (Stufe, Spell-IDs, sicher/möglich)
Data/Profiles.lua       Rollenziele, Standard-Filter je Profil, Instanz-Hinweise
Logic/Scoring.lua       Bewertung (ohne Spiel-API)
Logic/Engine.lua        Liest Gruppenfinder-Daten, Perspektive, Zauberbuchprüfung
Core.lua                Einstellungen, Events, /bgf, Sprache, Vorlagen
UI/List.lua             BGF-Liste, Zeilen, Bereiche
UI/Templates.xml        Zeilen-/Kopf-Vorlagen
UI/Tooltip.lua          Tooltip mit Begründung
UI/FilterBar.lua        Filterleiste
UI/Contact.lua          Anfrage-Button, Platzhalter, Versand
UI/Options.lua          Optionen und Vorlagen-Editor
UI/Main.lua             Einbindung in Blizzards Fenster, Größe, Greifpunkt
tests/                  Offline-Tests (vom Spiel nicht geladen)
```

Alle Einstellungen werden accountweit in `WTF\Account\<Account>\SavedVariables\BetterGroupFinder.lua` gespeichert.
