--[[
Smoke test with a mocked WoW UI (Lua 5.1). Run from the addon folder:
    lua tests/smoke.lua
Loads every file from the TOC in order, attaches the UI to a fake Group Finder, feeds
search results like the ones from the beta screenshots and clicks through the features.
This catches runtime errors (nil calls, wrong fields) - it does NOT prove the layout
looks right in the real client.
]]

local failures = 0
local function check(name, cond, detail)
	print((cond and "  ok   " or "  FAIL ") .. name .. ((not cond and detail) and ("  -> " .. tostring(detail)) or ""))
	if not cond then failures = failures + 1 end
end

-------------------------------------------------------------------------------
-- Generic frame mock
-------------------------------------------------------------------------------

local eventFrames = {}
local Frame = {}

local NUMBER_GETTERS = {
	GetWidth = 458, GetHeight = 535, GetScale = 1, GetEffectiveScale = 1, GetLeft = 20, GetTop = 900,
	GetFrameLevel = 5, GetStringWidth = 60, GetStringHeight = 12,
}

local function newFrame(kind, name)
	local f = { __kind = kind, __shown = true, __scripts = {}, __points = {}, __size = {} }
	setmetatable(f, Frame)
	if name then _G[name] = f end
	return f
end

local METHOD_PREFIXES = { "Set", "Get", "Is", "Create", "Register", "Enable", "Disable", "Clear", "Add",
	"Hook", "Show", "Hide", "Raise", "Lower", "Start", "Stop", "Unregister", "Has", "Can" }

local function isMethodName(key)
	if type(key) ~= "string" then return false end
	for _, p in ipairs(METHOD_PREFIXES) do
		if key:sub(1, #p) == p then return true end
	end
	return key == "ForEachFrame"
end

Frame.__index = function(self, key)
	if not isMethodName(key) then return nil end
	if NUMBER_GETTERS[key] then
		return function(s)
			if key == "GetWidth" and s.__size.w then return s.__size.w end
			if key == "GetHeight" and s.__size.h then return s.__size.h end
			if key == "GetScale" and s.__scale then return s.__scale end
			return NUMBER_GETTERS[key]
		end
	end
	if key == "CreateTexture" or key == "CreateFontString" or key == "CreateMaskTexture" or key == "GetFontString" then
		return function(s)
			s.__children = s.__children or {}
			local child = newFrame(key)
			table.insert(s.__children, child)
			return child
		end
	end
	if key == "SetScript" then return function(s, n, fn) s.__scripts[n] = fn end end
	if key == "GetScript" then return function(s, n) return s.__scripts[n] end end
	if key == "HookScript" then
		return function(s, n, fn)
			local old = s.__scripts[n]
			s.__scripts[n] = function(...) if old then old(...) end fn(...) end
		end
	end
	if key == "Show" then return function(s) s.__shown = true if s.__scripts.OnShow then s.__scripts.OnShow(s) end end end
	if key == "Hide" then return function(s) s.__shown = false end end
	if key == "SetShown" then return function(s, v) if v then s:Show() else s:Hide() end end end
	if key == "IsShown" then return function(s) return s.__shown end end
	if key == "SetText" then return function(s, t) s.__text = t end end
	if key == "GetText" then return function(s) return s.__text or "" end end
	if key == "SetWidth" then return function(s, w) s.__size.w = w end end
	if key == "SetHeight" then return function(s, h) s.__size.h = h end end
	if key == "SetSize" then return function(s, w, h) s.__size.w, s.__size.h = w, h end end
	if key == "SetScale" then return function(s, v) s.__scale = v end end
	if key == "SetChecked" then return function(s, v) s.__checked = v end end
	if key == "GetChecked" then return function(s) return s.__checked end end
	if key == "SetAtlas" then return function() return true end end
	if key == "RegisterEvent" then
		return function(s, e) eventFrames[s] = eventFrames[s] or {} eventFrames[s][e] = true end
	end
	if key == "ForEachFrame" then
		return function(s, fn) for _, fr in ipairs(s.__frames or {}) do fn(fr) end end
	end
	if key == "SetDataProvider" then
		return function(s, provider)
			s.__frames = {}
			local view = s.__view
			for _, data in ipairs(provider.items) do
				view.__factory(function(template, init)
					local fr = newFrame("Button")
					local mixin = (template == "BGFRowTemplate" and BGFRowMixin)
						or (template == "BGFHeaderTemplate" and BGFHeaderMixin) or BGFMessageMixin
					for k, v in pairs(mixin) do fr[k] = v end
					fr:OnLoad()
					init(fr, data)
					table.insert(s.__frames, fr)
				end, data)
				view.__extent(nil, data)
			end
		end
	end
	return function() return nil end
end

_G.CreateFrame = function(kind, name, parent, template)
	return newFrame(kind, name)
end

-------------------------------------------------------------------------------
-- WoW globals used by the addon
-------------------------------------------------------------------------------

_G.unpack = unpack
_G.GetLocale = function() return "deDE" end
_G.GetCurrentRegion = function() return 3 end
_G.IsBetaBuild = function() return false end
_G.InCombatLockdown = function() return false end
_G.C_Timer = { After = function(_, fn) fn() end }
_G.SlashCmdList = {}
_G.UISpecialFrames = {}
_G.tinsert = table.insert
_G.tContains = function(t, v) for _, x in ipairs(t) do if x == v then return true end end return false end
_G.hooksecurefunc = function(tbl, name, fn)
	local old = tbl[name]
	tbl[name] = function(...) local r = { old(...) } fn(...) return unpack(r) end
end
_G.geterrorhandler = function() return function(e) print("ERROR HANDLER: " .. tostring(e)) end end
_G.DEFAULT_CHAT_FRAME = { AddMessage = function(_, msg) _G.__lastPrint = msg end }
_G.GameTooltip = newFrame("GameTooltip")
_G.RAID_CLASS_COLORS = {}
for _, c in ipairs({ "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }) do
	RAID_CLASS_COLORS[c] = { r = 0.5, g = 0.5, b = 0.5 }
end
_G.LOCALIZED_CLASS_NAMES_MALE = { HUNTER = "Jäger", WARRIOR = "Krieger", PRIEST = "Priester", MAGE = "Magier", ROGUE = "Schurke", DRUID = "Druide", WARLOCK = "Hexenmeister", SHAMAN = "Schamane", PALADIN = "Paladin" }
_G.LEVEL_ABBR = "St."
_G.TANK, _G.HEALER, _G.DAMAGER = "Tank", "Heiler", "Schaden"
_G.SEND_MESSAGE, _G.GROUP_INVITE = "Nachricht senden", "Gruppeneinladung"
_G.LFGBROWSE_ACTIVITY_COUNT = "%d Aktivitäten"
_G.GetGeneralPlaystyleString = function(v) return ({ "Lernen", "Entspannt", "Kompetitiv", "Beförderung angeboten" })[v] or "" end
_G.CreateAtlasMarkup = function(a) return "|A:" .. a .. "|a" end
_G.Ambiguate = function(name) return (name:gsub("%-.*", "")) end
_G.ScrollBoxConstants = { RetainScrollPosition = true }
_G.CreateDataProvider = function(items) return { items = items } end
_G.CreateScrollBoxListLinearView = function()
	local v = {}
	function v:SetElementFactory(fn) self.__factory = fn end
	function v:SetElementExtentCalculator(fn) self.__extent = fn end
	return v
end
_G.ScrollUtil = { InitScrollBoxListWithScrollBar = function(box, _, view) box.__view = view end }
_G.PlaySound = function() end
_G.SOUNDKIT = { IG_MAINMENU_OPTION_CHECKBOX_ON = 1 }

-- Player: level 22 hunter, solo, DPS
local inGroup = false
_G.UnitExists = function(u) return u == "player" or (inGroup and u == "party1") end
_G.UnitClass = function(u) if u == "player" then return "Jäger", "HUNTER" end return "Priester", "PRIEST" end
_G.UnitLevel = function() return 22 end
_G.UnitName = function(u) return u == "player" and "Ibona" or "Elowen" end
_G.UnitIsUnit = function(a, b) return a == b end
_G.UnitGroupRolesAssigned = function(u) if u == "party1" then return "HEALER" end return inGroup and "DAMAGER" or "NONE" end
_G.UnitIsGroupLeader = function() return true end
_G.UnitIsGroupAssistant = function() return false end
_G.IsInGroup = function() return inGroup end
_G.IsInRaid = function() return false end
_G.GetNumGroupMembers = function() return inGroup and 2 or 0 end
_G.GetNumSubgroupMembers = function() return inGroup and 1 or 0 end
_G.C_LFGListRoles = { GetRoles = function() return { tank = false, healer = false, dps = true } end }
_G.C_SpellBook = { IsSpellKnown = function(id) return id == 1499 end }
_G.C_AddOns = { IsAddOnLoaded = function() return true end }

local sent = {}
_G.C_ChatInfo = {
	InChatMessagingLockdown = function() return false end,
	SendChatMessage = function(text, chatType, _, target) sent[#sent + 1] = { text = text, type = chatType, target = target } end,
}
local invited = {}
_G.C_PartyInfo = { InviteUnit = function(name) invited[#invited + 1] = name end }
_G.ChatFrameUtil = {
	SendTell = function() end,
	SendTellWithMessage = function(name, text) sent[#sent + 1] = { text = text, prefill = true, target = name } end,
}

-- Menu API: runs the generator immediately and records the buttons.
local lastMenu
local function menuDescription()
	local d = { buttons = {} }
	function d:CreateTitle(t) self.title = self.title or t end
	function d:CreateDivider() end
	function d:CreateButton(text, fn)
		local b = menuDescription()
		b.text, b.fn = text, fn
		function b:SetTooltip(fn2) self.tooltip = fn2 end
		table.insert(self.buttons, b)
		return b
	end
	return d
end
_G.MenuUtil = { CreateContextMenu = function(_, gen) lastMenu = menuDescription() gen(nil, lastMenu) end }
_G.Settings = nil

-- Group Finder data: activities and results like in the beta screenshots
local ACT = {
	[11] = { fullName = "Höhlen des Wehklagens", shortName = "", categoryID = 2, maxNumPlayers = 5, minLevel = 15, minLevelSuggestion = 15, maxLevelSuggestion = 24, mapID = 43 },
	[12] = { fullName = "Burg Shadowfang", shortName = "", categoryID = 2, maxNumPlayers = 5, minLevel = 20, minLevelSuggestion = 20, maxLevelSuggestion = 30, mapID = 33 },
	[13] = { fullName = "Ruinen von Lordaeron", shortName = "", categoryID = 2, maxNumPlayers = 5, minLevel = 15, minLevelSuggestion = 15, maxLevelSuggestion = 22, mapID = 9999 },
}
local RESULTS = {
	[1] = { leaderName = "Alde Eisenfaust", numMembers = 4, activityIDs = { 11 }, generalPlaystyle = 2,
		members = { { "WARRIOR", 18, "TANK", true }, { "PALADIN", 21, "DAMAGER" }, { "PRIEST", 18, "HEALER" }, { "ROGUE", 24, "DAMAGER" } } },
	[2] = { leaderName = "Selune Selunar", numMembers = 3, activityIDs = { 11 }, generalPlaystyle = 3, newPlayerFriendly = true,
		members = { { "PRIEST", 22, "HEALER", true }, { "WARRIOR", 19, "TANK" }, { "DRUID", 22, "DAMAGER" } } },
	[3] = { leaderName = "Zwerg Naseweis", numMembers = 4, activityIDs = { 12 }, generalPlaystyle = 2,
		members = { { "PRIEST", 21, "HEALER", true }, { "MAGE", 22, "DAMAGER" }, { "WARLOCK", 22, "DAMAGER" }, { "ROGUE", 22, "DAMAGER" } } },
	[4] = { leaderName = "Chronos Temporalis", numMembers = 1, activityIDs = { 11 }, generalPlaystyle = 2,
		members = { { "DRUID", 15, nil, true, { dps = true } } } },
	[5] = { leaderName = "Imogshaarig Bär", numMembers = 1, activityIDs = { 11 }, generalPlaystyle = 2,
		members = { { "DRUID", 16, nil, true, { tank = true } } } },
	[6] = { leaderName = "Nandhelia Mondklinge", numMembers = 1, activityIDs = { 11, 13 }, generalPlaystyle = 2,
		members = { { "WARRIOR", 19, nil, true, { dps = true } } } },
}
_G.C_LFGList = {
	GetSearchResultInfo = function(id)
		local r = RESULTS[id]
		if not r then return nil end
		return { searchResultID = id, leaderName = r.leaderName, numMembers = r.numMembers, activityIDs = r.activityIDs,
			generalPlaystyle = r.generalPlaystyle, newPlayerFriendly = r.newPlayerFriendly, hasSelf = false, isDelisted = false }
	end,
	GetSearchResultPlayerInfo = function(id, i)
		local m = RESULTS[id].members[i]
		if not m then return nil end
		return { classFilename = m[1], level = m[2], assignedRole = m[3] or "DAMAGER", isLeader = m[4], lfgRoles = m[5] or { dps = true }, name = "Member" .. i }
	end,
	GetActivityInfoTable = function(id) return ACT[id] end,
	GetActiveEntryInfo = function() return nil end,
	GetFilteredSearchResults = function() return 6, { 1, 2, 3, 4, 5, 6 } end,
}

-- Fake Group Finder frames
local parent = newFrame("Frame", "LFGParentFrame")
parent.__size = { w = 458, h = 535 }
local browse = newFrame("Frame", "LFGBrowseFrame")
browse.RefreshButton = newFrame("Button")
browse.ScrollBox = newFrame("Frame")
browse.ScrollBar = newFrame("Frame")
browse.SendMessageButton = newFrame("Button")
browse.GroupInviteButton = newFrame("Button")
browse.ActivityDropdown = { selectedValues = {}, ValueIsSelected = function() return false end }
browse.CategoryDropdown = { GetValue = function() return 2 end, SetValue = function() end, HookScript = function() end }
browse.results = { 1, 2, 3, 4, 5, 6 }
browse.totalResults = 6
browse.searching = false
browse.UpdateResults = function() end
browse.UpdateButtonState = function() end
browse.CreateSearchEntryMenu = function() end
browse.selectionBehavior = { HasSelection = function() return false end }

-------------------------------------------------------------------------------
-- Load the addon in TOC order
-------------------------------------------------------------------------------

local ns = {}
for line in io.lines("BetterGroupFinder.toc") do
	local file = line:match("^([%w_\\/]+%.lua)%s*$")
	if file then
		local path = file:gsub("\\", "/")
		local chunk, err = loadfile(path)
		check("load " .. path, chunk ~= nil, err)
		if chunk then
			local ok, runErr = pcall(chunk, "BetterGroupFinder", ns)
			check("run " .. path, ok, runErr)
		end
	end
end

local function fire(event, ...)
	for f, events in pairs(eventFrames) do
		if events[event] and f.__scripts.OnEvent then f.__scripts.OnEvent(f, event, ...) end
	end
end

print("Events")
local ok, err = pcall(fire, "ADDON_LOADED", "BetterGroupFinder")
check("ADDON_LOADED creates the saved variables and attaches the UI", ok and BetterGroupFinderDB ~= nil and ns.UI.attached, err)
ok, err = pcall(fire, "PLAYER_LOGIN")
check("PLAYER_LOGIN builds the options", ok, err)

print("List")
ok, err = pcall(ns.UI.Refresh)
check("refresh without errors", ok, err)
local sections = ns.List.sections
check("sections built", sections and sections.total == 6, sections and sections.total)
local frames = ns.List.scrollBox.__frames or {}
check("rows and headers rendered", #frames >= 5, #frames)
check("Blizzard list hidden while BGF active", browse.ScrollBox.__shown == false)
for _, e in ipairs(sections.groups) do print(("      group  %-18s score %s"):format(e.info.leaderName, e.result.score)) end
for _, e in ipairs(sections.players) do print(("      player %-18s score %s"):format(e.info.leaderName, e.result.score)) end
for _, e in ipairs(sections.excluded) do print(("      out    %-18s %s"):format(e.info.leaderName, ns.FormatReason(e.result.excludeReason))) end
local excludedNames = {}
for _, e in ipairs(sections.excluded) do excludedNames[e.info.leaderName] = ns.FormatReason(e.result.excludeReason) end
check("Zwerg Naseweis (only a tank missing) is sorted out for a hunter", excludedNames["Zwerg Naseweis"] ~= nil, excludedNames["Zwerg Naseweis"])

print("Filter bar")
ok, err = pcall(ns.UI.filterButton.__scripts.OnClick)
check("filter button opens the bar", ok and ns.db.filterOpen and ns.FilterBar.frame.__shown, err)
check("window grows by the bar height", (parent.__size.h or 0) > 535, parent.__size.h)
check("window wider while BGF list is shown", (parent.__size.w or 0) > 458, parent.__size.w)
local chip = ns.FilterBar.frame.AbilityChips[3]
ok, err = pcall(chip.__scripts.OnClick, chip)
check("ability chip cycles state", ok and ns.db.abilityStates.dungeon[chip.ability] ~= ns.DEFAULT_ABILITY_STATES.dungeon[chip.ability], err)
local roleChip = ns.FilterBar.frame.RoleChips[1]
ok, err = pcall(roleChip.__scripts.OnClick, roleChip)
check("role chip switches to manual roles", ok and next(ns.db.roleChips) ~= nil, err)
ns.FilterBar.ResetFilters()
ok, err = pcall(ns.FilterBar.frame.ViewNormal.__scripts.OnClick, ns.FilterBar.frame.ViewNormal)
check("normal view renders", ok and ns.db.compact == false, err)
ns.FilterBar.SetCompact(true)

print("Request button")
local row
for _, fr in ipairs(ns.List.scrollBox.__frames) do
	if fr.entry and fr.entry.info.leaderName == "Selune Selunar" then row = fr end
end
check("row for Selune Selunar exists", row ~= nil)
ok, err = pcall(row.OnClick, row, "LeftButton")
check("clicking a row selects it", ok and ns.List.selectedID == 2, err)
ok, err = pcall(ns.UI.requestButton.__scripts.OnClick, ns.UI.requestButton)
check("request menu opens", ok and lastMenu ~= nil, err)
check("menu title names the leader", lastMenu and lastMenu.title and lastMenu.title:find("Selune", 1, true) ~= nil, lastMenu and lastMenu.title)
local first = lastMenu.buttons[1]
ok, err = pcall(first.fn)
local msg = sent[#sent]
check("template is sent as whisper automatically", ok and msg and msg.type == "WHISPER" and not msg.prefill, err)
check("placeholders filled (class, role, level, instance)", msg and msg.text:find("Jäger", 1, true) and msg.text:find("DPS", 1, true)
	and msg.text:find("22", 1, true) and msg.text:find("Höhlen des Wehklagens", 1, true) and not msg.text:find("{", 1, true), msg and msg.text)
print("      -> " .. (msg and msg.text or "?"))
local english = lastMenu.buttons[3]
ok, err = pcall(english.fn)
msg = sent[#sent]
check("English fallback templates are offered", ok and msg and msg.text:find("Hunter", 1, true) ~= nil, msg and msg.text)
print("      -> " .. (msg and msg.text or "?"))

-- Lockdown: message goes to the chat box instead
C_ChatInfo.InChatMessagingLockdown = function() return true end
pcall(first.fn)
check("during chat lockdown the text is prefilled instead of sent", sent[#sent].prefill == true)
C_ChatInfo.InChatMessagingLockdown = function() return false end

-- Invite a solo player as group leader
inGroup = true
ns.UI.Refresh()
local bear
for _, fr in ipairs(ns.List.scrollBox.__frames) do
	if fr.entry and fr.entry.info.leaderName == "Imogshaarig Bär" then bear = fr end
end
if bear then
	bear:OnClick("LeftButton")
	ns.UI.requestButton.__scripts.OnClick(ns.UI.requestButton)
	pcall(lastMenu.buttons[1].fn)
	check("inviting a solo player invites and whispers", invited[#invited] == "Imogshaarig Bär" and sent[#sent].text:find("Imogshaarig", 1, true) ~= nil, sent[#sent].text)
	print("      -> " .. sent[#sent].text)
else
	check("solo tank listed for your group", false, "not in visible rows")
end

print("Tooltip, resize, toggles")
ok, err = pcall(function() row:OnEnter() row:OnLeave() end)
check("tooltip shows and hides", ok, err)
local grip = ns.UI.grip
ok, err = pcall(function()
	grip.__scripts.OnMouseDown(grip, "LeftButton")
	_G.GetCursorPosition = function() return 700, 300 end
	grip.__scripts.OnUpdate(grip)
	grip.__scripts.OnMouseUp(grip, "LeftButton")
end)
check("dragging the grip changes and saves the scale", ok and ns.db.scale ~= 1, err or ns.db.scale)
_G.InCombatLockdown = function() return true end
local before = ns.db.scale
pcall(grip.__scripts.OnMouseDown, grip, "LeftButton")
check("no resizing in combat", grip.__scripts.OnUpdate == nil or ns.db.scale == before)
_G.InCombatLockdown = function() return false end
ok, err = pcall(SlashCmdList.BETTERGROUPFINDER, "off")
check("/bgf off shows Blizzard's list again", ok and browse.ScrollBox.__shown == true and ns.List.scrollBox.__shown == false, err)
ok, err = pcall(SlashCmdList.BETTERGROUPFINDER, "on")
check("/bgf on switches back", ok and ns.List.scrollBox.__shown == true, err)
ok, err = pcall(SlashCmdList.BETTERGROUPFINDER, "debug")
check("/bgf debug", ok, err)
ok, err = pcall(SlashCmdList.BETTERGROUPFINDER, "")
check("/bgf opens options", ok, err)

print(failures == 0 and "\nall smoke checks passed" or ("\n" .. failures .. " smoke checks failed"))
os.exit(failures == 0 and 0 or 1)
