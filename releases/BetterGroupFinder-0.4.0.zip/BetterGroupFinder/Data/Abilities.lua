local _, ns = ...

--[[
Group utility per class for WoW Forever.

Each entry: ability id, level the class learns it, rank-1 spell IDs (used only to check
YOUR OWN spellbook), and `possible = true` when it depends on a talent, a pet, a shield
or a creature type, so BGF can only say "may bring".

Source status (October 2026, beta build 1.60.1):
  * Learn levels and spell IDs follow WoW Classic. Forever keeps the classic spell set
    for these utilities as far as public class previews show, but they are NOT verified
    in the Forever client. If a spell ID does not exist in Forever, BGF notices that
    your own spellbook check fails and falls back to class + level.
  * Verified Forever changes: no Bloodlust/Heroism for shamans (only a personal
    talent), Fear Ward for all priests at level 20.
  * Combined filters (only one class provides them): "summon" = summoning (20) and
    healthstones (10, counted as "possible" until 20); "buff_stamina" = stamina and Fear Ward.
  * Everything here is meant to be edited when Blizzard changes classes.
]]

-- Ability ids, default weight (points when a group gains it) and the profiles in which
-- they are preferred out of the box.
ns.ABILITIES = {
	{ id = "cc",           weight = 10 },
	{ id = "interrupt",    weight = 8 },
	{ id = "curse",        weight = 6 },
	{ id = "magic",        weight = 6 },
	{ id = "poison",       weight = 5 },
	{ id = "disease",      weight = 5 },
	{ id = "battleres",    weight = 6 },
	{ id = "summon",       weight = 7 },  -- summoning & healthstones (warlock); no meeting stones in Forever
	{ id = "buff_stamina", weight = 4 },  -- stamina & Fear Ward (priest)
	{ id = "buff_int",     weight = 2 },
	{ id = "buff_wild",    weight = 3 },
	{ id = "buff_ap",      weight = 2 },
}

ns.ABILITY_BY_ID = {}
for i, ability in ipairs(ns.ABILITIES) do
	ability.order = i
	ns.ABILITY_BY_ID[ability.id] = ability
end

ns.CLASS_ORDER = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }

ns.CLASS_ABILITIES = {
	WARRIOR = {
		{ a = "buff_ap",   level = 1,  spells = { 6673 } },               -- Battle Shout
		{ a = "interrupt", level = 12, spells = { 72 }, possible = true }, -- Shield Bash (needs a shield)
		{ a = "interrupt", level = 38, spells = { 6552 } },               -- Pummel
	},
	PALADIN = {
		{ a = "buff_ap",   level = 4,  spells = { 19740 } },              -- Blessing of Might
		{ a = "poison",    level = 8,  spells = { 1152 } },               -- Purify
		{ a = "disease",   level = 8,  spells = { 1152 } },               -- Purify
		{ a = "interrupt", level = 8,  spells = { 853 } },                -- Hammer of Justice (stun)
		{ a = "cc",        level = 24, spells = { 2878 }, possible = true }, -- Turn Undead (undead only)
		{ a = "magic",     level = 42, spells = { 4987 } },               -- Cleanse
	},
	HUNTER = {
		{ a = "cc",        level = 20, spells = { 1499 } },               -- Freezing Trap
	},
	ROGUE = {
		{ a = "cc",        level = 10, spells = { 6770 } },               -- Sap
		{ a = "interrupt", level = 12, spells = { 1766 } },               -- Kick
	},
	PRIEST = {
		{ a = "buff_stamina", level = 1, spells = { 1243 } },             -- Power Word: Fortitude (+ Fear Ward from 20, all priests in Forever)
		{ a = "disease",   level = 14, spells = { 528 } },                -- Cure Disease
		{ a = "magic",     level = 18, spells = { 527 } },                -- Dispel Magic
		{ a = "cc",        level = 20, spells = { 9484 }, possible = true }, -- Shackle Undead (undead only)
	},
	SHAMAN = {
		{ a = "interrupt", level = 4,  spells = { 8042 } },               -- Earth Shock
		{ a = "buff_ap",   level = 10, spells = { 8075 } },               -- Strength of Earth Totem
		{ a = "poison",    level = 16, spells = { 526 } },                -- Cure Poison
		{ a = "disease",   level = 22, spells = { 2870 } },               -- Cure Disease
	},
	MAGE = {
		{ a = "buff_int",  level = 1,  spells = { 1459 } },               -- Arcane Intellect
		{ a = "cc",        level = 8,  spells = { 118 } },                -- Polymorph
		{ a = "curse",     level = 18, spells = { 475 } },                -- Remove Lesser Curse
		{ a = "interrupt", level = 24, spells = { 2139 } },               -- Counterspell
	},
	WARLOCK = {
		{ a = "cc",        level = 8,  spells = { 5782 }, possible = true }, -- Fear (risky in dungeons)
		{ a = "summon",    level = 10, possible = true },                 -- Healthstones only (no summoning before 20)
		{ a = "battleres", level = 18, spells = { 693 } },                -- Create Soulstone
		{ a = "summon",    level = 20, spells = { 698 } },                -- Ritual of Summoning (+ healthstones)
		{ a = "cc",        level = 28, spells = { 710 } },                -- Banish (demons/elementals)
		{ a = "magic",     level = 30, possible = true },                 -- Felhunter: Devour Magic (pet)
	},
	DRUID = {
		{ a = "buff_wild", level = 1,  spells = { 1126 } },               -- Mark of the Wild
		{ a = "cc",        level = 8,  spells = { 339 } },                -- Entangling Roots (indoors in Forever)
		{ a = "poison",    level = 14, spells = { 8946 } },               -- Cure Poison
		{ a = "battleres", level = 20, spells = { 20484 } },              -- Rebirth
		{ a = "curse",     level = 24, spells = { 2782 } },               -- Remove Curse
	},
}
