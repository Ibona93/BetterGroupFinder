local _, ns = ...

--[[
Abbreviation rules for instance names that do not fit the column, per client language.
Applied one after another until the text fits: "Höhlen des Wehklagens" -> "Höhlen d. Wehklagens".
Patterns use Lua frontier patterns (%f) so only whole words are replaced.
]]

local function word(w) return "%f[%w]" .. w .. "%f[%W]" end

ns.ABBREVIATIONS = {
	deDE = {
		{ word("des"), "d." }, { word("der"), "d." }, { word("den"), "d." }, { word("dem"), "d." },
		{ word("von"), "v." }, { word("vom"), "v." }, { word("und"), "u." }, { word("im"), "i." },
	},
	enUS = {
		{ "^The ", "" }, { word("of the"), "o.t." }, { word("of"), "o." }, { word("the"), "" }, { word("and"), "&" },
	},
	frFR = {
		{ word("des"), "d." }, { word("du"), "d." }, { word("de la"), "d.l." }, { word("de"), "d." }, { word("et"), "&" },
	},
	esES = {
		{ word("de los"), "d.l." }, { word("de las"), "d.l." }, { word("del"), "d." }, { word("de"), "d." }, { word("y"), "&" },
	},
	ptBR = {
		{ word("dos"), "d." }, { word("das"), "d." }, { word("do"), "d." }, { word("da"), "d." }, { word("de"), "d." }, { word("e"), "&" },
	},
	itIT = {
		{ word("della"), "d." }, { word("delle"), "d." }, { word("dei"), "d." }, { word("del"), "d." }, { word("di"), "d." }, { word("e"), "&" },
	},
}
ns.ABBREVIATIONS.esMX = ns.ABBREVIATIONS.esES

-- Collapses double spaces left by removed words.
function ns.CleanSpaces(text)
	return (text:gsub("%s%s+", " "):gsub("^%s+", ""):gsub("%s+$", ""))
end

-- Returns successively shorter variants of an instance name.
function ns.AbbreviationSteps(text, locale)
	local steps = {}
	local current = text
	for _, rule in ipairs(ns.ABBREVIATIONS[locale] or {}) do
		local nextText = ns.CleanSpaces((current:gsub(rule[1], rule[2])))
		if nextText ~= current then
			current = nextText
			steps[#steps + 1] = current
		end
	end
	return steps
end

-- "Aldarin Schattentanz" -> "Aldarin S."; single names stay as they are.
function ns.ShortName(name)
	local first, rest = name:match("^(%S+)%s+(.+)$")
	if not first then return nil end
	local initial = rest:match("^[%z\1-\127\194-\244][\128-\191]*")
	return initial and (first .. " " .. initial .. ".") or nil
end
