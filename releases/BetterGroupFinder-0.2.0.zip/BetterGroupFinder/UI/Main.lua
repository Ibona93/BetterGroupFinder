local _, ns = ...

--[[
UI wiring inside Blizzard's Group Finder (LFGParentFrame / LFGBrowseFrame):
  * BGF list over Blizzard's list (Blizzard's list and footer buttons hidden while active)
  * filter button and view button next to Refresh, filter bar under the header
  * "Templates" button between "Send Message" and "Group Invite"
The window keeps Blizzard's original width; only the filter bar makes it taller
(changed out of combat only). Nothing of Blizzard's code is replaced; BGF only hooks,
reads and shows/hides.
]]

local UI = {}
ns.UI = UI

local LIST_TOP = -112          -- Blizzard's list top offset in LFGBrowseFrame
local LIST_BOTTOM = 40
local FILTER_TOP = -84
local GOLD = { 1, 0.82, 0 }

local base = {}               -- original height of LFGParentFrame
local pendingLayout = false

local function inCombat()
	return InCombatLockdown and InCombatLockdown()
end

-------------------------------------------------------------------------------
-- Blizzard list visibility
-------------------------------------------------------------------------------

local function bgfActive()
	return ns.db.enabled and LFGBrowseFrame and LFGBrowseFrame:IsShown()
end

local function setBlizzardListShown(shown)
	local f = LFGBrowseFrame
	if not f then return end
	for _, child in ipairs({ f.ScrollBox, f.ScrollBar, f.SendMessageButton, f.GroupInviteButton }) do
		if child then
			if shown then child:Show() else child:Hide() end
		end
	end
	if shown and f.ScrollBar and f.ScrollBox and f.ScrollBox.HasScrollableExtent then
		local ok, scrollable = pcall(f.ScrollBox.HasScrollableExtent, f.ScrollBox)
		if ok and not scrollable then f.ScrollBar:Hide() end
	end
end

local function keepHiddenWhileActive(frame)
	if frame and frame.HookScript then
		frame:HookScript("OnShow", function(self)
			if ns.db.enabled then self:Hide() end
		end)
	end
end

-------------------------------------------------------------------------------
-- Layout: height grows with the filter bar
-------------------------------------------------------------------------------

function UI.ApplyLayout()
	local parent = LFGParentFrame
	if not parent or not base.height then return end
	local bar = ns.FilterBar.frame
	local open = ns.db.filterOpen and LFGBrowseFrame:IsShown()
	local combat = inCombat()
	pendingLayout = combat

	local barHeight = 0
	if open then
		bar:ClearAllPoints()
		bar:SetPoint("TOPLEFT", LFGBrowseFrame, "TOPLEFT", 8, FILTER_TOP)
		bar:SetPoint("TOPRIGHT", LFGBrowseFrame, "TOPRIGHT", -8, FILTER_TOP)
		bar:Show()
		barHeight = ns.FilterBar.Layout()
		bar:SetHeight(barHeight)
		ns.FilterBar.Update()
	else
		bar:Hide()
	end

	if not combat then
		parent:SetHeight(base.height + barHeight)
	end

	local scrollBox = ns.List.scrollBox
	scrollBox:ClearAllPoints()
	scrollBox:SetPoint("TOPLEFT", LFGBrowseFrame, "TOPLEFT", 7, LIST_TOP - barHeight)
	scrollBox:SetPoint("BOTTOMRIGHT", LFGBrowseFrame, "BOTTOMRIGHT", -24, LIST_BOTTOM)
	UI.UpdateFilterButton()
end

function UI.OnCombatStart() end

function UI.OnCombatEnd()
	if pendingLayout then UI.ApplyLayout() end
end

-------------------------------------------------------------------------------
-- Enable / disable
-------------------------------------------------------------------------------

function UI.ApplyEnabled()
	if not UI.attached then return end
	local enabled = ns.db.enabled
	setBlizzardListShown(not enabled)
	ns.List.SetShown(enabled)
	UI.messageButton:SetShown(enabled)
	UI.inviteButton:SetShown(enabled)
	UI.ApplyLayout()
	ns.FilterBar.Update()
	if enabled then ns.RequestRefresh() end
	UI.UpdateButtons()
	UI.UpdateViewButton()
end

-------------------------------------------------------------------------------
-- Selection and footer buttons
-------------------------------------------------------------------------------

local function blizzardSelectedID()
	local f = LFGBrowseFrame
	if not f or not f.selectionBehavior then return nil end
	local ok, has = pcall(f.selectionBehavior.HasSelection, f.selectionBehavior)
	if not ok or not has then return nil end
	local okData, data = pcall(f.selectionBehavior.GetSelectedElementData, f.selectionBehavior)
	local element = okData and data and data[1]
	return element and element.data and element.data.resultID
end

function UI.GetSelectedEntry()
	if ns.db.enabled then
		return ns.List.GetSelectedEntry()
	end
	local id = blizzardSelectedID()
	if not id then return nil end
	return ns.Engine.EvaluateResult(id, ns.Engine.GetMySide())
end

function UI.UpdateButtons()
	if not UI.attached then return end
	local entry = UI.GetSelectedEntry()
	local valid = entry and not entry.own and entry.info and not entry.info.isDelisted
	UI.requestButton:SetEnabled(valid and true or false)
	UI.messageButton:SetEnabled(valid and true or false)
	local canInvite = valid and entry.isSolo and ns.Contact.Mode(entry) == "invite"
	UI.inviteButton:SetEnabled(canInvite and true or false)
end

local function createFooter()
	local f = LFGBrowseFrame
	local L = ns.L

	UI.messageButton = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	UI.messageButton:SetSize(111, 28)
	UI.messageButton:SetPoint("BOTTOMLEFT", 21, 16)
	UI.messageButton:SetText(SEND_MESSAGE or "Send Message")
	UI.messageButton:SetScript("OnClick", function()
		local entry = UI.GetSelectedEntry()
		if entry and entry.info and entry.info.leaderName and ChatFrameUtil and ChatFrameUtil.SendTell then
			ChatFrameUtil.SendTell(entry.info.leaderName)
		end
	end)

	UI.inviteButton = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	UI.inviteButton:SetSize(109, 28)
	UI.inviteButton:SetPoint("BOTTOMRIGHT", -21, 16)
	UI.inviteButton:SetText(GROUP_INVITE or "Group Invite")
	UI.inviteButton:SetScript("OnClick", function()
		local entry = UI.GetSelectedEntry()
		if entry and entry.info and entry.info.leaderName and C_PartyInfo and C_PartyInfo.InviteUnit then
			pcall(C_PartyInfo.InviteUnit, entry.info.leaderName)
		end
	end)

	UI.requestButton = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	UI.requestButton:SetSize(100, 28)
	UI.requestButton:SetPoint("BOTTOM", 0, 16)
	UI.requestButton:SetText(L.REQUEST)
	UI.requestButton:SetScript("OnClick", function(self)
		ns.Contact.OpenMenu(self, UI.GetSelectedEntry())
	end)
	UI.requestButton:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L.REQUEST, 1, 1, 1)
		GameTooltip:AddLine(L.REQUEST_TT, nil, nil, nil, true)
		GameTooltip:Show()
	end)
	UI.requestButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-------------------------------------------------------------------------------
-- Header buttons: same square frame as Refresh, plain drawn icons
-------------------------------------------------------------------------------

local function bar(parent, width, height, x, y)
	local t = parent:CreateTexture(nil, "ARTWORK", nil, 5)
	t:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1)
	t:SetSize(width, height)
	t:SetPoint("CENTER", x, y)
	return t
end

local function squareButton(anchor, tooltipTitle, tooltipText)
	local b = CreateFrame("Button", nil, LFGBrowseFrame)
	b:SetSize(32, 32)
	b:SetPoint("LEFT", anchor, "RIGHT", 2, 0)
	b:SetNormalTexture("Interface\\Buttons\\UI-SquareButton-Up")
	b:SetPushedTexture("Interface\\Buttons\\UI-SquareButton-Down")
	b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	b:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(type(tooltipTitle) == "function" and tooltipTitle() or tooltipTitle, 1, 1, 1)
		GameTooltip:AddLine(tooltipText, nil, nil, nil, true)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	b:SetScript("OnMouseDown", function(self) if self.Icon then self.Icon:SetPoint("CENTER", -1, -1) end end)
	b:SetScript("OnMouseUp", function(self) if self.Icon then self.Icon:SetPoint("CENTER", 0, 0) end end)
	b.Active = b:CreateTexture(nil, "OVERLAY")
	b.Active:SetAllPoints()
	b.Active:SetTexture("Interface\\Buttons\\CheckButtonHilight")
	b.Active:SetBlendMode("ADD")
	b.Active:Hide()
	b.Icon = CreateFrame("Frame", nil, b)
	b.Icon:SetSize(16, 16)
	b.Icon:SetPoint("CENTER")
	return b
end

local function createHeaderButtons()
	local L = ns.L
	local anchor = LFGBrowseFrame.RefreshButton

	-- Filter: three lines getting shorter (funnel)
	local filter = squareButton(anchor, L.FILTER_BUTTON_TT, L.FILTER_BUTTON_TT2)
	bar(filter.Icon, 14, 2, -1, 4)
	bar(filter.Icon, 9, 2, -1, 0)
	bar(filter.Icon, 4, 2, -1, -4)
	filter:SetScript("OnClick", function()
		if inCombat() then ns.Print(L.COMBAT_FILTER) return end
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) end
		ns.db.filterOpen = not ns.db.filterOpen
		UI.ApplyLayout()
	end)
	UI.filterButton = filter

	-- View: two thick lines (normal) or four thin lines (compact)
	local view = squareButton(filter, function()
		return L.VIEW_TOGGLE_TT:format(ns.db.compact and L.VIEW_COMPACT or L.VIEW_NORMAL)
	end, L.VIEW_TOGGLE_TT2)
	view.NormalLines = { bar(view.Icon, 13, 4, -1, 3), bar(view.Icon, 13, 4, -1, -4) }
	view.CompactLines = { bar(view.Icon, 13, 2, -1, 5), bar(view.Icon, 13, 2, -1, 1),
		bar(view.Icon, 13, 2, -1, -3), bar(view.Icon, 13, 2, -1, -7) }
	view:SetScript("OnClick", function(self)
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) end
		ns.FilterBar.SetCompact(not ns.db.compact)
		if GameTooltip:IsOwned(self) then self:GetScript("OnEnter")(self) end
	end)
	UI.viewButton = view
end

function UI.UpdateFilterButton()
	if UI.filterButton then
		UI.filterButton.Active:SetShown(ns.db.filterOpen and ns.FilterBar.frame and ns.FilterBar.frame:IsShown() or false)
	end
end

function UI.UpdateViewButton()
	local v = UI.viewButton
	if not v then return end
	for _, t in ipairs(v.NormalLines) do t:SetShown(not ns.db.compact) end
	for _, t in ipairs(v.CompactLines) do t:SetShown(ns.db.compact) end
	v:SetEnabled(ns.db.enabled)
	v.Icon:SetAlpha(ns.db.enabled and 1 or 0.4)
end

-------------------------------------------------------------------------------
-- Refresh
-------------------------------------------------------------------------------

function UI.Refresh()
	if not UI.attached or not LFGBrowseFrame then return end
	ns.FilterBar.Update()
	UI.UpdateViewButton()
	if not bgfActive() then
		UI.UpdateButtons()
		return
	end
	setBlizzardListShown(false)
	local f = LFGBrowseFrame
	if f.searching then
		ns.List.SetSections(nil)
	else
		local results = f.results
		if type(results) ~= "table" then
			local ok, _, filtered = false, nil, nil
			if C_LFGList and C_LFGList.GetFilteredSearchResults then ok, _, filtered = pcall(C_LFGList.GetFilteredSearchResults) end
			results = ok and filtered or {}
		end
		if f.searchFailed or (f.totalResults or 0) == 0 then results = {} end
		ns.List.SetSections(ns.Engine.BuildSections(results))
	end
	UI.UpdateButtons()
end

-------------------------------------------------------------------------------
-- Setup
-------------------------------------------------------------------------------

function UI.Setup()
	if UI.attached or not LFGBrowseFrame or not LFGParentFrame then return end
	base.height = LFGParentFrame:GetHeight()

	ns.List.Create(LFGBrowseFrame)
	ns.FilterBar.Create(LFGBrowseFrame)
	createFooter()
	createHeaderButtons()
	UI.attached = true

	keepHiddenWhileActive(LFGBrowseFrame.ScrollBox)
	keepHiddenWhileActive(LFGBrowseFrame.ScrollBar)
	keepHiddenWhileActive(LFGBrowseFrame.SendMessageButton)
	keepHiddenWhileActive(LFGBrowseFrame.GroupInviteButton)

	if LFGBrowseFrame.UpdateResults then
		hooksecurefunc(LFGBrowseFrame, "UpdateResults", function() ns.RequestRefresh() end)
	end
	if LFGBrowseFrame.UpdateButtonState then
		hooksecurefunc(LFGBrowseFrame, "UpdateButtonState", function() UI.UpdateButtons() end)
	end
	LFGBrowseFrame:HookScript("OnShow", function()
		UI.ApplyLayout()
		ns.RequestRefresh()
	end)
	LFGBrowseFrame:HookScript("OnHide", function()
		ns.Tooltip.Hide()
		UI.ApplyLayout()
	end)
	if LFGBrowseFrame.CategoryDropdown then
		pcall(hooksecurefunc, LFGBrowseFrame.CategoryDropdown, "SetValue", function() ns.FilterBar.Update() end)
	end

	UI.ApplyEnabled()
	ns.Debug("UI attached")
end
